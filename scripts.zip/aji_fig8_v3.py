# =====================================================
# FIGURE 6.1 (v3) - KOMPOSIT CAPE (PC3) DAN GERAK VERTIKAL 850 hPa (PC4)
#
# Perubahan dibanding versi sebelumnya (Reviewer 3, Minor 12 & 16; Reviewer 1):
#   1. Kedua fase (PC >= +0,5 dan PC <= -0,5) ditampilkan, bukan hanya fase positif.
#   2. Anomali dihitung terhadap rata-rata DJF 1981/82-2009/10 (sama dengan Fig. 3 dan 6),
#      bukan terhadap klimatologi seluruh periode. Sebelumnya tidak sesuai dengan caption.
#   3. Uji signifikansi: Welch t-test fase komposit vs musim lainnya, FDR 5% (titik).
#   4. Gerak vertikal dinyatakan sebagai -omega (positif = naik/ascent) dengan skala merah = positif,
#      searah dengan semua gambar lain; sebelumnya omega positif (turun) berwarna biru -> menyesatkan.
#   5. MASKING di bawah permukaan: bila file tekanan permukaan (sp) diberikan, sel yang tekanan
#      permukaannya < 850 hPa (+ margin) ditutup abu-abu pada panel omega. Tanpa file sp, panel omega
#      diberi tanda "UNMASKED" dan TIDAK boleh dipakai di naskah.
#   6. pcolormesh pada grid asli (bukan contourf yang menciptakan bentuk segitiga pada grid 15x15).
#   7. Daftar tahun komposit semua PC disimpan ke CSV (Reviewer 3, Minor 12).
#   8. Judul netral: tanpa kata "modulated".
#
# sp = ERA5 monthly averaged reanalysis, variabel 'surface_pressure', area 4,5N-1N, 114,5E-118E,
#      1955-2025 (unduh dari CDS dengan cara yang sama seperti cape.nc).
#
# Jalankan:  py aji_fig8_v3.py
# Butuh: numpy, pandas, xarray, geopandas, matplotlib, scipy
# =====================================================
import os
import numpy as np
import pandas as pd
import xarray as xr
import geopandas as gpd
import matplotlib.pyplot as plt
from scipy import stats

BASE = r"C:\Users\user\Documents\data_jurnal\newdata"
csv_pc = os.path.join(BASE, "hasil_pca", "pc_scores_promax_v2.csv")
file_cape = os.path.join(BASE, "cape.nc")
file_w = os.path.join(BASE, "pressure.nc")
file_sp = os.path.join(BASE, "sp.nc")                    # <- unduh dulu; boleh belum ada
shp_path = os.path.join(BASE, "gadm41_IDN_shp", "gadm41_IDN_2.shp")
out_png = os.path.join(BASE, "Figure6_1_CAPE_and_Omega_v3.png")
out_pdf = os.path.join(BASE, "Figure6_1_CAPE_and_Omega_v3.pdf")
out_yrs = os.path.join(BASE, "Komposit_tahun_PC1_PC4.csv")
if not os.path.exists(csv_pc):                          # untuk uji di folder lain
    csv_pc, file_cape, file_w, file_sp, shp_path = ("pc_scores_promax_v2.csv", "cape.nc", "pressure.nc",
                                                    "sp.nc", "kaltara_test.shp")
    out_png, out_pdf, out_yrs = "Figure6_1_v3.png", "Figure6_1_v3.pdf", "Komposit_tahun_v3.csv"

THR = 0.5
BASE_YEARS = (1982, 2010)          # tahun JANUARI -> DJF 1981/82 - 2009/10
SP_LIMIT_PA = 85000.0 + 2000.0     # sel dengan sp rata-rata DJF < 870 hPa dianggap 850 hPa di bawah/dekat tanah
ALPHA = 0.05


def bh_mask(p, alpha=ALPHA):
    p = np.asarray(p, float)
    ok = np.isfinite(p)
    out = np.zeros(p.shape, bool)
    pv = p[ok]
    order = np.argsort(pv)
    thr = alpha * (np.arange(1, pv.size + 1) / pv.size)
    below = pv[order] <= thr
    sig = np.zeros(pv.size, bool)
    if below.any():
        sig[order[: np.where(below)[0].max() + 1]] = True
    out[ok] = sig
    return out


def djf_by_january_year(da, y0=1956, y1=2025):
    """Rata-rata Des(Y-1), Jan(Y), Feb(Y); indeks = Y (tahun Januari). Hanya musim lengkap."""
    if "valid_time" in da.dims:
        da = da.rename({"valid_time": "time"})
    t = pd.DatetimeIndex(da["time"].values)
    arr = da.values.astype("float64")
    pos = {(y, m): i for i, (y, m) in enumerate(zip(t.year, t.month))}
    ys, out = [], []
    for Y in range(y0, y1 + 1):
        keys = [(Y - 1, 12), (Y, 1), (Y, 2)]
        if all(k in pos for k in keys):
            out.append(np.mean([arr[pos[k]] for k in keys], axis=0))
            ys.append(Y)
    return np.array(ys), np.stack(out), da["latitude"].values, da["longitude"].values


def composite(years, field, scores):
    """Anomali komposit + mask signifikan (Welch t, FDR) untuk fase pos/neg."""
    b = (years >= BASE_YEARS[0]) & (years <= BASE_YEARS[1])
    anom = field - field[b].mean(0)
    out = {}
    for ph, sel in (("pos", scores >= THR), ("neg", scores <= -THR)):
        m = anom[sel].mean(0)
        _, p = stats.ttest_ind(anom[sel], anom[~sel], axis=0, equal_var=False)
        out[ph] = (m, bh_mask(np.nan_to_num(p, nan=1.0)), int(sel.sum()))
    return out


# ---------------- skor dan tahun komposit ----------------
sc = pd.read_csv(csv_pc).set_index("Year")
rows = []
for pc in ["PC1", "PC2", "PC3", "PC4"]:
    rows.append(dict(PC=pc, phase=f">= +{THR}", n=int((sc[pc] >= THR).sum()),
                     years=" ".join(map(str, sc.index[sc[pc] >= THR]))))
    rows.append(dict(PC=pc, phase=f"<= -{THR}", n=int((sc[pc] <= -THR).sum()),
                     years=" ".join(map(str, sc.index[sc[pc] <= -THR]))))
pd.DataFrame(rows).to_csv(out_yrs, index=False)
print("Tahun komposit disimpan:", out_yrs, "(tahun = Januari musim DJF)")

# ---------------- CAPE (PC3) ----------------
ds = xr.open_dataset(file_cape)
var = "cape" if "cape" in ds.data_vars else list(ds.data_vars)[0]
yrs, cape, lat, lon = djf_by_january_year(ds[var])
keep = np.isin(yrs, sc.index.values)
yrs_c = yrs[keep]
comp_cape = composite(yrs_c, cape[keep], sc.loc[yrs_c, "PC3"].values)

# ---------------- omega 850 (PC4) ----------------
dw = xr.open_dataset(file_w)
lev = "pressure_level" if "pressure_level" in dw.dims else "level"
dw = dw.sel({lev: 850})
yrs2, w, lat2, lon2 = djf_by_january_year(dw["w"])
keep2 = np.isin(yrs2, sc.index.values)
yrs_w = yrs2[keep2]
comp_w = composite(yrs_w, -w[keep2], sc.loc[yrs_w, "PC4"].values)      # -omega: positif = naik

masked = False
below = np.zeros_like(lat2[:, None] * lon2[None, :], dtype=bool)
if os.path.exists(file_sp):
    dsp = xr.open_dataset(file_sp)
    # sp.nc bisa punya grid/periode berbeda (mis. 17 baris lintang, 861 bulan) -> samakan dengan grid omega
    spda = dsp["sp"].reindex(latitude=lat2, longitude=lon2, method="nearest", tolerance=1e-3)
    ysp, sp, _, _ = djf_by_january_year(spda)
    spm = sp.mean(0)
    if not np.isfinite(spm).all():
        print("PERINGATAN: sebagian sel sp tidak cocok dengan grid omega (NaN); periksa lat/lon sp.nc")
    below = np.nan_to_num(spm, nan=1e9) < SP_LIMIT_PA
    masked = True
    print(f"Sel 850 hPa di bawah/dekat permukaan (sp < {SP_LIMIT_PA/100:.0f} hPa): {int(below.sum())} dari {below.size}")
else:
    print("PERINGATAN: sp.nc tidak ditemukan -> panel omega TIDAK di-mask (jangan dipakai di naskah).")

# ---------------- gambar ----------------
kab = gpd.read_file(shp_path)
kaltara = kab[kab["NAME_1"].str.upper() == "KALIMANTAN UTARA"]
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 12, "axes.titlesize": 12.5,
                     "axes.labelsize": 12})
fig, axes = plt.subplots(2, 2, figsize=(12, 10), sharex=True, sharey=True, constrained_layout=True)


def draw(ax, lon, lat, comp, label, vmax, mask_below=None):
    m, sig, n = comp
    m = np.where(mask_below, np.nan, m) if mask_below is not None else m
    ax.set_facecolor("#cfcfcf")
    im = ax.pcolormesh(lon, lat, m, cmap="RdBu_r", vmin=-vmax, vmax=vmax, shading="nearest")
    LON, LAT = np.meshgrid(lon, lat)
    s = sig if mask_below is None else (sig & ~mask_below)
    ax.scatter(LON[s], LAT[s], s=16, c="k", marker=".", linewidths=0)
    kaltara.boundary.plot(ax=ax, color="k", linewidth=0.9)
    ax.set_xlim(lon.min() - 0.125, lon.max() + 0.125)
    ax.set_ylim(lat.min() - 0.125, lat.max() + 0.125)
    ax.set_aspect("equal", adjustable="box")
    ax.grid(True, ls=":", alpha=0.4)
    ax.set_title(f"{label} (n = {n})", loc="left", fontweight="bold")
    return im


vc = float(np.ceil(max(np.nanmax(np.abs(comp_cape[p][0])) for p in ("pos", "neg")) / 10) * 10)
vw = float(max(np.nanmax(np.abs(comp_w[p][0])) for p in ("pos", "neg")))
vw = float(np.ceil(vw * 1000) / 1000) if vw > 0 else 0.01
im1 = draw(axes[0, 0], lon, lat, comp_cape["pos"], "(a) CAPE, PC3 ≥ +0.5", vc)
draw(axes[0, 1], lon, lat, comp_cape["neg"], "(b) CAPE, PC3 ≤ −0.5", vc)
mb = below if masked else None
im2 = draw(axes[1, 0], lon2, lat2, comp_w["pos"], "(c) −ω 850 hPa, PC4 ≥ +0.5", vw, mb)
draw(axes[1, 1], lon2, lat2, comp_w["neg"], "(d) −ω 850 hPa, PC4 ≤ −0.5", vw, mb)
if not masked:
    for ax in axes[1]:
        ax.text(0.5, 0.5, "UNMASKED – below-ground cells\nnot removed; do not use", transform=ax.transAxes,
                ha="center", va="center", color="crimson", fontsize=14, fontweight="bold", alpha=0.7)
for ax in axes[0]:
    ax.set_xlabel("")
for ax in axes[1]:
    ax.set_xlabel("Longitude (°E)")
for ax in axes[:, 1]:
    ax.set_ylabel("")
for ax in axes[:, 0]:
    ax.set_ylabel("Latitude (°N)")
cb1 = fig.colorbar(im1, ax=axes[0], fraction=0.04, pad=0.02)
cb1.set_label("CAPE anomaly (J kg$^{-1}$)")
cb2 = fig.colorbar(im2, ax=axes[1], fraction=0.04, pad=0.02)
cb2.set_label("−ω anomaly (Pa s$^{-1}$); positive = anomalous ascent")
fig.suptitle("DJF composite anomalies of CAPE (PC3) and 850 hPa vertical motion (PC4)\n"
             "relative to DJF 1981/82–2009/10; dots = significant (Welch t-test, FDR 5%)"
             + ("; grey = 850 hPa below/near surface" if masked else ""),
             fontsize=12.5, fontweight="bold")
fig.savefig(out_png, dpi=300, facecolor="white")
fig.savefig(out_pdf)
print("Saved:", out_png, out_pdf)
