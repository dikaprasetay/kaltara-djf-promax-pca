"""
Pola loading PC1-PC4 (Promax) dari HASIL ANALISIS BARU -- pengganti aji_fig3.py.

Jalankan (folder newdata):
  py fig_loading_v2.py --loadings hasil_pca\\loadings_promax_v2.csv --nc avgad.nc --shp gadm41_IDN_shp\\gadm41_IDN_1.shp --out Fig_loading_v2

Tidak menghitung PCA lagi: hanya membaca loadings_promax_v2.csv dari analisis_pca_promax_70musim.py,
sehingga gambar pasti sama dengan Tabel 1, Tabel 2, dan skor PC.
"""
import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from gaya_gambar import terapkan_gaya, CMAP, simpan


def read_grid(nc_path, n_lat=15, n_lon=15):
    try:
        import xarray as xr
        ds = xr.open_dataset(nc_path)
        return ds['latitude'].values, ds['longitude'].values
    except Exception as e:
        print('Peringatan: koordinat dari nc gagal dibaca (%s); dipakai grid 1.0-4.5N, 114.5-118.0E.' % e)
        return np.linspace(4.5, 1.0, n_lat), np.linspace(114.5, 118.0, n_lon)


def read_boundary(shp_path, bbox):
    if not shp_path:
        return None
    try:
        import geopandas as gpd
        from shapely.geometry import box
        g = gpd.read_file(shp_path).to_crs('EPSG:4326')
        x0, y0, x1, y1 = bbox
        pad = 1.0   # potong lebih lebar dari area gambar supaya garis tepi potongan tidak muncul
        return gpd.clip(g, box(x0 - pad, y0 - pad, x1 + pad, y1 + pad))
    except Exception as e:
        print('Peringatan: batas administrasi dilewati (%s)' % e)
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--loadings', required=True)
    ap.add_argument('--nc', default='avgad.nc')
    ap.add_argument('--shp', default=None)
    ap.add_argument('--out', default='Fig_loading_v2')
    a = ap.parse_args()
    terapkan_gaya()
    L = pd.read_csv(a.loadings)
    lat, lon = read_grid(a.nc)
    n_lat, n_lon = len(lat), len(lon)
    pcs = [c for c in L.columns if c.upper().startswith('PC')]
    assert len(L) == n_lat * n_lon, 'Jumlah baris loading (%d) != %d x %d grid' % (len(L), n_lat, n_lon)
    bnd = read_boundary(a.shp, (lon.min(), lat.min(), lon.max(), lat.max()))

    fig, axes = plt.subplots(1, len(pcs), figsize=(4.6 * len(pcs), 5.2), sharex=True, sharey=True)
    for i, (ax, pc) in enumerate(zip(np.atleast_1d(axes), pcs)):
        field = L[pc].values.reshape(n_lat, n_lon)
        im = ax.pcolormesh(lon, lat, field, cmap=CMAP, vmin=-1, vmax=1, shading='nearest')
        if bnd is not None and not bnd.empty:
            bnd.boundary.plot(ax=ax, color='black', linewidth=0.8)
        ax.set_xlim(lon.min() - 0.125, lon.max() + 0.125)
        ax.set_ylim(min(lat) - 0.125, max(lat) + 0.125)
        ax.set_title(f'({"abcd"[i]}) {pc}', loc='left')
        ax.set_xlabel('Longitude (°E)')
        if i == 0:
            ax.set_ylabel('Latitude (°N)')
        ax.grid(True, ls=':', lw=0.5, alpha=0.6)
        ax.set_aspect('equal', adjustable='box')
    cb = fig.colorbar(im, ax=list(np.atleast_1d(axes)), orientation='horizontal', fraction=0.05, pad=0.14, aspect=40)
    cb.set_label('Promax pattern loading (positive = wetter)')
    simpan(fig, a.out)


if __name__ == '__main__':
    main()
