import os
import xarray as xr
import numpy as np
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from scipy.stats import pearsonr
from scipy.interpolate import RegularGridInterpolator
from sklearn.decomposition import PCA

# ==============================================================================
# 1. PATH DATA DAN PERSIAPAN DATASET EKSTENSI REGIONAL
# ==============================================================================
shp_dir = r"C:\Users\user\Documents\data_jurnal\newdata\gadm41_IDN_shp"
path_kab = os.path.join(shp_dir, "gadm41_IDN_2.shp")

print("--- Membaca Batas Administrasi Kaltara untuk Overlay ---")
gdf_kab = gpd.read_file(path_kab)
kaltara_shp = gdf_kab[gdf_kab['NAME_1'].str.upper() == 'KALIMANTAN UTARA'].copy()

print("--- Memproses Dataset Curah Hujan ERA5 (avgad.nc) ---")
ds_ad = xr.open_dataset('avgad.nc')
if 'expver' in ds_ad.coords or 'expver' in ds_ad.data_vars:
    ds_ad = ds_ad.drop_vars('expver', errors='ignore')

# Mengunci orientasi koordinat grid standardisasi (Ascending)
ds_ad = ds_ad.sortby('latitude', ascending=True)
ds_ad = ds_ad.sortby('longitude', ascending=True)

time_coords = ds_ad['valid_time'].values
if isinstance(time_coords, np.ndarray) and np.issubdtype(time_coords.dtype, np.datetime64):
    time_idx = pd.DatetimeIndex(time_coords)
else:
    time_idx = pd.to_datetime(time_coords)

ds_ad.coords['year'] = ('valid_time', time_idx.year)
ds_ad.coords['month'] = ('valid_time', time_idx.month)

# ==============================================================================
# 2. EKSTRAKSI DAN HITUNG ANOMALI MUSIM DJF (1955 - 2025)
# ==============================================================================
print("--- Ekstraksi dan Perhitungan Anomali Musiman DJF (1955-2025) ---")
years_range = np.arange(1955, 2026)
n_years = len(years_range)

lon_orig = ds_ad['longitude'].values
lat_orig = ds_ad['latitude'].values
n_lat, n_lon = len(lat_orig), len(lon_orig)

# Matriks penampung rata-rata akumulasi DJF tiap tahun (n_years x n_lat x n_lon)
djf_yearly_rain = np.zeros((n_years, n_lat, n_lon))

for idx, yr in enumerate(years_range):
    # Mengambil Desember (Tahun-1), Januari (Tahun Aktual), Februari (Tahun Aktual)
    ds_dec = ds_ad.sel(valid_time=(ds_ad['month'] == 12) & (ds_ad['year'] == yr - 1))
    ds_jan = ds_ad.sel(valid_time=(ds_ad['month'] == 1) & (ds_ad['year'] == yr))
    ds_feb = ds_ad.sel(valid_time=(ds_ad['month'] == 2) & (ds_ad['year'] == yr))
    
    # Validasi ketersediaan data untuk mengantisipasi batas ujung tahun
    m_slices = []
    if len(ds_dec['valid_time']) > 0: m_slices.append(ds_dec['tp'].values * 1000.0)
    if len(ds_jan['valid_time']) > 0: m_slices.append(ds_jan['tp'].values * 1000.0)
    if len(ds_feb['valid_time']) > 0: m_slices.append(ds_feb['tp'].values * 1000.0)
    
    if len(m_slices) > 0:
        djf_yearly_rain[idx, :, :] = np.mean(np.concatenate(m_slices, axis=0), axis=0)
    else:
        djf_yearly_rain[idx, :, :] = np.nan

# Mengatasi missing values / NaNs dengan interpolasi median temporal
if np.isnan(djf_yearly_rain).any():
    col_mean = np.nannanmean(djf_yearly_rain, axis=0)
    inds = np.where(np.isnan(djf_yearly_rain))
    djf_yearly_rain[inds] = np.take(col_mean, inds[1:])

# Menghitung Nilai Anomali Curah Hujan DJF
climatology_djf = np.mean(djf_yearly_rain, axis=0)
djf_anomaly = djf_yearly_rain - climatology_djf

# ==============================================================================
# 3. KALKULASI REOF (ROTATED EOF) UNTUK MENGEKSTRAK PC SCORE 1 - 4
# ==============================================================================
print("--- Menghitung REOF & Ekstraksi PC Scores 1-4 ---")
# Reshape dimensi spasial 2D menjadi 1D untuk analisis matriks PCA (time x space)
djf_anomaly_flat = djf_anomaly.reshape(n_years, n_lat * n_lon)

# Ekstrak 4 Komponen Utama Teratas (EOF murni)
pca = PCA(n_components=4)
pc_scores_pure = pca.fit_transform(djf_anomaly_flat) # Dimensi: 71 tahun x 4 PC
loadings_pure = pca.components_.T * np.sqrt(pca.explained_variance_)

# Implementasi Fungsi Rotasi Varimax Ortopedis
def varimax_rotation(loadings, max_iter=500, tolerance=1e-6):
    X = loadings.copy()
    p, k = X.shape
    R = np.eye(k)
    d = 0
    for i in range(max_iter):
        d_old = d
        Lambda = np.dot(X, R)
        alpha = np.dot(X.T, Lambda**3 - (1.0 / p) * np.dot(Lambda, np.diag(np.sum(Lambda**2, axis=0))))
        U, S, Vt = np.linalg.svd(alpha)
        R = np.dot(U, Vt)
        d = np.sum(S)
        if d_old != 0 and d / d_old < 1 + tolerance:
            break
    return np.dot(X, R), R

# Hitung REOF Scores (PC Scores akhir hasil rotasi varimax)
loadings_rotated, rotation_matrix = varimax_rotation(loadings_pure)
pc_scores_rotated = np.dot(pc_scores_pure, rotation_matrix)

# Standardisasi Akhir PC Scores (Temporal Indices)
pc_scores_final = (pc_scores_rotated - np.mean(pc_scores_rotated, axis=0)) / np.std(pc_scores_rotated, axis=0)

# Simpan cadangan data PC Score ke bentuk CSV
df_pc = pd.DataFrame(pc_scores_final, columns=['PC1', 'PC2', 'PC3', 'PC4'], index=years_range)
df_pc.to_csv('PC_scores_DJF_1955_2025.csv', index_label='Year')

# ==============================================================================
# 4. KALKULASI KORELASI SPASIAL REGIONAL DAN INTERPOLASI HIGH-RES
# ==============================================================================
print("--- Melakukan Kalkulasi Peta Korelasi Spasial Regional ---")
extent = [114.3, 118.2, 0.8, 4.7]

lon_high = np.linspace(extent[0], extent[1], 500)
lat_high = np.linspace(extent[2], extent[3], 500)
lon_mesh, lat_mesh = np.meshgrid(lon_high, lat_high)

correlation_maps = []

for pc_idx in range(4):
    r_matrix = np.zeros((n_lat, n_lon))
    current_pc_score = pc_scores_final[:, pc_idx]
    
    for i in range(n_lat):
        for j in range(n_lon):
            grid_anomaly_series = djf_anomaly[:, i, j]
            r_val, _ = pearsonr(current_pc_score, grid_anomaly_series)
            r_matrix[i, j] = r_val if not np.isnan(r_val) else 0.0
            
    # Proses Interpolasi Bilinear Halus Mengikuti Grid Resolusi Tinggi
    interp = RegularGridInterpolator((lat_orig, lon_orig), r_matrix, bounds_error=False, fill_value=0.0)
    grid_points = np.array([lat_mesh.flatten(), lon_mesh.flatten()]).T
    r_matrix_high = interp(grid_points).reshape(500, 500)
    correlation_maps.append(r_matrix_high)

# ==============================================================================
# 5. VISUALISASI MULTI-PANEL MATRIKS 2x2 REPLIKASI FIGURE 4 STYLE
# ==============================================================================
print("--- Plotting Kartografi Figure 4: Korelasi Spasial Regional ---")
fig, axs = plt.subplots(2, 2, figsize=(20, 18), dpi=300)
axs = axs.flatten()

# Rentang koefisien korelasi pearson dikunci simetris
vmin, vmax = -0.7, 0.7
levels = np.linspace(vmin, vmax, 29)

letters = ['a', 'b', 'c', 'd']
pc_names = ['PC1', 'PC2', 'PC3', 'PC4']

for idx, (ax, data, name, letter) in enumerate(zip(axs, correlation_maps, pc_names, letters)):
    # Plot kontur korelasi regional penuh mencakup darat dan laut
    im = ax.contourf(lon_mesh, lat_mesh, data, levels=levels, cmap='RdBu_r', extend='both', zorder=1)
    
    # Overlay garis batas administrasi Kaltara di atas kontur regional tanpa memotong data
    kaltara_shp.plot(ax=ax, facecolor='none', edgecolor='black', linewidth=1.5, zorder=2)
    
    # Kunci aspek rasio kartografi peta bumi
    ax.set_aspect('equal', adjustable='box')
    
    # Formatting Batas Koordinat Axis
    ax.set_xlim(extent[0], extent[1])
    ax.set_ylim(extent[2], extent[3])
    ax.set_xlabel('Bujur / Longitude (°E)', fontsize=12, fontweight='bold', labelpad=6)
    ax.set_ylabel('Lintang / Latitude (°N)', fontsize=12, fontweight='bold', labelpad=6)
    ax.grid(True, linestyle=':', color='gray', alpha=0.5, zorder=3)
    ax.tick_params(labelsize=10)
    
    # Pengaturan Judul Panel Publikasi
    ax.set_title(f'Spatial Correlation Map: {name}', fontsize=14, fontweight='bold', pad=15)
    ax.text(0.04, 0.94, f'({letter})', transform=ax.transAxes, fontsize=18, fontweight='bold', zorder=4)

# Colorbar Bersama Horizontal Diletakkan di Bagian Bawah Gambar Komposit
cbar_ax = fig.add_axes([0.25, 0.05, 0.50, 0.018])
cbar = fig.colorbar(im, cax=cbar_ax, orientation='horizontal')
cbar.set_label("Pearson's Correlation Coefficient (r)", fontsize=13, fontweight='bold', labelpad=8)
cbar.ax.tick_params(labelsize=11)

plt.subplots_adjust(bottom=0.12, hspace=0.22, wspace=0.15)
output_filename = 'Figure_4_Correlation_Maps_REOF_DJF.png'
plt.savefig(output_filename, bbox_inches='tight', dpi=300)
plt.close()

print(f"--- SELESAI MUTLAK: Figure Korelasi Regional '{output_filename}' Sukses Dibuat ---")