import os
import geopandas as gpd
import matplotlib.pyplot as plt
from matplotlib.patches import ConnectionPatch

# ==============================================================================
# 1. PENGATURAN DIREKTORI DAN PATH DATA SHAPEFILE
# ==============================================================================
# Path menuju folder ekstraksi GADM Indonesia
shp_dir = r"C:\Users\user\Documents\data_jurnal\newdata\gadm41_IDN_shp"

path_level1 = os.path.join(shp_dir, "gadm41_IDN_1.shp")  # Level Provinsi
path_level2 = os.path.join(shp_dir, "gadm41_IDN_2.shp")  # Level Kabupaten/Kota

print("--- Membaca dan Memotong (Subsetting) Data Spasial ---")
# Reading shapefile menggunakan geopandas
gdf_prov = gpd.read_file(path_level1)
gdf_kab  = gpd.read_file(path_level2)

# Filter spasial khusus untuk wilayah studi: Provinsi Kalimantan Utara
kaltara_kab = gdf_kab[gdf_kab['NAME_1'].str.upper() == 'KALIMANTAN UTARA'].copy()

# ==============================================================================
# 2. INISIALISASI KANVAS MULTI-PANEL (MAP WITH INSET)
# ==============================================================================
# Membuat figure dengan resolusi tinggi standar publikasi ilmiah (300 DPI)
fig = plt.figure(figsize=(12, 10), dpi=300)

# Mengatur tata letak GridSpec: Peta Utama (Kaltara) dan Peta Sisipan (Inset Indonesia)
# Subplot utama untuk Peta Wilayah Studi
ax_main = fig.add_subplot(1, 1, 1)

print("-> Menghasilkan Peta Utama: Kalimantan Utara Berdasarkan Kabupaten/Kota")
# Plot Peta Utama: Pembagian Kabupaten/Kota di Kalimantan Utara
kaltara_kab.plot(
    ax=ax_main,
    column='NAME_2',          # Pewarnaan berdasarkan nama kabupaten/kota
    cmap='Set3',              # Skema warna kualitatif yang kontras dan bersih
    edgecolor='#4d4d4d',      # Garis batas administrasi abu-abu gelap
    linewidth=0.8,
    legend=True,              # Tampilkan legenda otomatis
    legend_kwds={
        'loc': 'lower left',
        'title': 'Regency / City',
        'frameon': True,
        'shadow': False,
        'facecolor': '#ffffff',
        'edgecolor': '#cccccc',
        'fontsize': 9,
        'title_fontsize': 10
    }
)

# Menambahkan Label Teks Nama Kabupaten/Kota tepat di titik centroid geometri
for idx, row in kaltara_kab.iterrows():
    centroid = row['geometry'].centroid
    # Lakukan sedikit pergeseran manual jika visualisasi label bertubrukan
    ax_main.text(
        centroid.x, centroid.y, 
        s=row['NAME_2'], 
        fontsize=9, 
        fontweight='bold',
        color='#2c3e50',
        ha='center', 
        va='center',
        bbox=dict(boxstyle="round,pad=0.2", fc='#ffffff', ec='none', alpha=0.6)
    )

# Mengatur tampilan grid koordinat dan ornamen kartografi peta utama
ax_main.grid(True, linestyle='--', linewidth=0.5, color='#bdc3c7', alpha=0.7)
ax_main.set_title("(a)", fontsize=13, fontweight='bold', loc='left')
ax_main.set_xlabel("Longitude (°E)", fontsize=10)
ax_main.set_ylabel("Latitude (°N)", fontsize=10)

# ==============================================================================
# 3. PEMBUATAN PETA SISIPAN (INSET MAP - INDONESIA MACRO)
# ==============================================================================
print("-> Menghasilkan Peta Sisipan (Inset Map): Orientasi Geografis Indonesia")
# Menempatkan posisi koordinat sumbu peta sisipan di pojok kanan bawah peta utama
# Struktur orientasi: [left, bottom, width, height] dalam fraksi nilai 0-1
ax_inset = fig.add_axes([0.62, 0.15, 0.26, 0.20])

# Plot seluruh batas provinsi Indonesia sebagai latar belakang makro
gdf_prov.plot(ax=ax_inset, color='#e0e0e0', edgecolor='#ffffff', linewidth=0.3)

# Highlight area Kalimantan Utara di dalam peta Indonesia dengan warna merah mencolok
kaltara_prov = gdf_prov[gdf_prov['NAME_1'].str.upper() == 'KALIMANTAN UTARA']
kaltara_prov.plot(ax=ax_inset, color='#e74c3c', edgecolor='#c0392b', linewidth=0.5)

# Batasi koordinat geografis inset agar fokus pada bentang kepulauan Indonesia
ax_inset.set_xlim(95, 142)
ax_inset.set_ylim(-11, 8)

# Hilangkan label angka derajat koordinat pada inset map agar terlihat minimalis dan bersih
ax_inset.set_xticks([])
ax_inset.set_yticks([])
ax_inset.set_title("Location in Indonesia", fontsize=8, fontweight='bold', color='#333333')

# Memberikan frame kotak luar berwarna abu-abu pada peta sisipan
for spine in ax_inset.spines.values():
    spine.set_edgecolor('#95a5a6')
    spine.set_linewidth(1)

# ==============================================================================
# 4. MENAMBAHKAN GARIS HUBUNG INDIKATOR SPASIAL (CONNECTION LINES)
# ==============================================================================
print("-> Menghubungkan batas spasial antar panel peta")
# Mengambil batas kotak ekstrem (bounding box) dari area Kalimantan Utara
xmin, ymin, xmax, ymax = kaltara_kab.total_bounds

# Gambar kotak indikator penanda (Extent Box) berwarna merah di dalam peta inset Indonesia
ax_inset.plot(
    [xmin, xmax, xmax, xmin, xmin], 
    [ymin, ymin, ymax, ymax, ymin], 
    color='#e74c3c', linewidth=1.2, linestyle='-', transform=ax_inset.transData
)

# Menghubungkan garis jangkar kartografi dari Peta Utama menuju Kotak Indikator Inset
con1 = ConnectionPatch(
    xyA=(xmin, ymin), coordsA=ax_main.transData,
    xyB=(xmin, ymin), coordsB=ax_inset.transData,
    color='#e74c3c', linestyle=':', linewidth=0.8, alpha=0.8
)
con2 = ConnectionPatch(
    xyA=(xmax, ymax), coordsA=ax_main.transData,
    xyB=(xmax, ymax), coordsB=ax_inset.transData,
    color='#e74c3c', linestyle=':', linewidth=0.8, alpha=0.8
)
fig.gca().add_artist(con1)
fig.gca().add_artist(con2)

# ==============================================================================
# 5. RETENSI FORMAT DAN EKSPOR PETA KE PNG RESOLUSI TINGGI
# ==============================================================================
output_filename = "Figure_1a_Study_Area.png"
plt.savefig(output_filename, bbox_inches='tight', dpi=300)
plt.close()

print(f"========================================================================")
print(f"-> SUKSES: File gambar publikasi '{output_filename}' (300 DPI) telah dibuat.")
print(f"========================================================================")