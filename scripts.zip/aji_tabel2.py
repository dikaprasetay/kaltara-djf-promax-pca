import xarray as xr
import pandas as pd
import numpy as np
from scipy.stats import kendalltau
import matplotlib.pyplot as plt

# ==============================================================================
# 0. BYPASS ERROR SCIKIT-LEARN LANGSUNG DI NAMESPACE INTERNAL FACTOR_ANALYZER
# ==============================================================================
import factor_analyzer.factor_analyzer
orig_check_array = factor_analyzer.factor_analyzer.check_array

def patched_check_array(*args, **kwargs):
    if 'force_all_finite' in kwargs:
        kwargs['ensure_all_finite'] = kwargs.pop('force_all_finite')
    return orig_check_array(*args, **kwargs)

factor_analyzer.factor_analyzer.check_array = patched_check_array
from factor_analyzer import FactorAnalyzer

# ==============================================================================
# 1. MEMBACA & PROSES DATA
# ==============================================================================
ds = xr.open_dataset('avgad.nc')

if 'expver' in ds.coords or 'expver' in ds.data_vars:
    ds = ds.drop_vars('expver', errors='ignore')

ds['tp'] = ds['tp'] * 1000
time_index = pd.DatetimeIndex(ds['valid_time'].values)
ds = ds.assign_coords(year=('valid_time', time_index.year), month=('valid_time', time_index.month))

djf_spatial_list = []
years_list = []

for yr in range(1955, 2026):
    mask = ((ds['year'] == yr - 1) & (ds['month'] == 12)) | \
           ((ds['year'] == yr) & (ds['month'].isin([1, 2])))
    
    subset = ds['tp'].sel(valid_time=mask)
    if len(subset['valid_time']) == 3:
        djf_spatial_list.append(subset.mean(dim='valid_time'))
        years_list.append(yr)

time_coords = pd.to_datetime([f"{yr}-01-01" for yr in years_list])
djf_rain = xr.concat(djf_spatial_list, dim='time')
djf_rain = djf_rain.assign_coords(time=time_coords)

# ==============================================================================
# 2. PCA DENGAN ROTASI PROMAX
# ==============================================================================
coslat = np.cos(np.deg2rad(djf_rain['latitude']))
weights = np.sqrt(coslat)
djf_weighted = djf_rain * weights

stacked = djf_weighted.stack(space=['latitude', 'longitude'])
stacked_np = stacked.values  

valid_mask = ~np.isnan(stacked_np[0, :])
data_2d = stacked_np[:, valid_mask]  

fa = FactorAnalyzer(n_factors=4, rotation='promax', method='principal')
fa.fit(data_2d)

pc_scores = fa.transform(data_2d)
pc_scores = (pc_scores - pc_scores.mean(axis=0)) / pc_scores.std(axis=0)

df_pcs = pd.DataFrame(pc_scores, columns=['PC1', 'PC2', 'PC3', 'PC4'])
df_pcs['Year'] = years_list

# KOREKSI TANDA (La Nina = Basah)
df_pcs['PC1'] = df_pcs['PC1'] * -1  

df_pcs.to_csv('pc_scores_promax.csv', index=False)

# ==============================================================================
# 3. KORELASI KENDALL TAU-B & EXPORT TABEL (MENGGUNAKAN FILE BARU)
# ==============================================================================
df_indices = pd.read_csv('indeks_iklim.csv')  # <-- FILE SUDAH DIGANTI

df_pcs['Year'] = df_pcs['Year'].astype(int)
df_indices['Year'] = df_indices['Year'].astype(int)

df_merged = pd.merge(df_pcs, df_indices, on='Year', how='inner')

indeks_global = ['DMI', 'Nino34', 'PDO', 'WPI']
pc_columns = ['PC1', 'PC2', 'PC3', 'PC4']
tabel1_results = []

for idx in indeks_global:
    row_data = {'Indeks Iklim': idx}
    for pc in pc_columns:
        if idx in df_merged.columns and pc in df_merged.columns:
            valid_df = df_merged[[idx, pc]].dropna()
            if len(valid_df) > 0:
                tau, _ = kendalltau(valid_df[idx], valid_df[pc])
                row_data[pc] = f"{tau:.3f}"
            else:
                row_data[pc] = "N/A"
        else:
            row_data[pc] = "N/A"
    tabel1_results.append(row_data)

df_tabel1 = pd.DataFrame(tabel1_results)
df_tabel1.to_csv('Tabel_1_Korelasi_Jurnal.csv', index=False)

print(df_tabel1.to_string(index=False))

fig, ax = plt.subplots(figsize=(9, 3), dpi=300)
ax.axis('off')
ax.axis('tight')

table = ax.table(cellText=df_tabel1.values, colLabels=df_tabel1.columns, cellLoc='center', loc='center')
table.auto_set_font_size(False)
table.set_fontsize(10)
table.scale(1.1, 1.7)

for (row, col), cell in table.get_celld().items():
    if row == 0:
        cell.set_text_props(weight='bold', color='white')
        cell.set_facecolor('#1f4e78')
    elif row % 2 == 0:
        cell.set_facecolor('#f2f5f9')

plt.savefig('Tabel_1_Korelasi_Jurnal.png', bbox_inches='tight', dpi=300)
print("-> Selesai! Gambar Tabel_1_Korelasi_Jurnal.png telah dibuat.")