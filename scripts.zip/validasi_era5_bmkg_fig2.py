"""
Validasi ERA5 vs BMKG (DJF) + Figure 2 (scatter) + cek jumlah musim DJF.

Jalankan di environment yang sudah punya xarray (env_sst):
  py validasi_era5_bmkg_fig2.py --era5 avgad.nc --bmkg Data_BMKG_Kaltara_DJF_1991_2024.xlsx --out hasil_fig2

Keluaran (folder --out):
  ERA5_DJF_regional_mean.csv      deret DJF ERA5 (mm/bulan) untuk semua musim lengkap
  Validasi_ERA5_vs_BMKG.csv       statistik validasi
  Figure2_ERA5_vs_BMKG.png/.pdf   scatter ERA5 vs BMKG
Tempel isi cetakan terminal ke chat bila ingin dicek bersama.
"""
import argparse, os
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


# ---------- I/O ----------
def load_era5_tp(path):
    import xarray as xr
    ds = xr.open_dataset(path)
    t = pd.DatetimeIndex(pd.to_datetime(ds['valid_time'].values))
    tp = ds['tp'].values.astype('float64')          # (time, lat, lon), satuan m
    lat = ds['latitude'].values
    expver = ds['expver'].values if 'expver' in ds else None
    return t, tp, lat, expver


def load_bmkg(path):
    df = pd.read_excel(path)
    df.columns = ['date', 'p']
    df['year'] = df['date'].astype(str).str[:4].astype(int)   # tahun Desember
    return df.set_index('year')['p'].rename('bmkg')


# ---------- perhitungan ----------
def to_mm_month(t, tp_m_per_day):
    """ERA5 'monthly means' (stepType avgad): tp = rata-rata akumulasi HARIAN (m/hari).
    mm/bulan = tp * 1000 * jumlah hari dalam bulan."""
    days = np.asarray(t.days_in_month, dtype='float64')
    return tp_m_per_day * 1000.0 * days[:, None, None]


def area_mean(x, lat):
    w = np.cos(np.deg2rad(lat))[None, :, None] * np.ones_like(x)
    ok = np.isfinite(x)
    return np.where(ok, x * w, 0).sum((1, 2)) / np.where(ok, w, 0).sum((1, 2))


def djf_series(t, series):
    """Rata-rata Des(y), Jan(y+1), Feb(y+1); indeks = tahun Desember. Hanya musim lengkap.
    Pakai kunci (tahun, bulan) supaya tidak bergantung pada tipe/resolusi tanggal pandas."""
    vals = np.asarray(series, dtype='float64')
    d = {(int(y), int(m)): v for y, m, v in zip(t.year, t.month, vals)}
    out = {}
    for y in sorted({int(y) for y in t.year}):
        keys = [(y, 12), (y + 1, 1), (y + 1, 2)]
        if all(k in d and np.isfinite(d[k]) for k in keys):
            out[y] = float(np.mean([d[k] for k in keys]))
    return pd.Series(out, name='era5', dtype='float64')


def validate(era5, bmkg):
    d = pd.concat([bmkg, era5], axis=1, join='inner').dropna()
    x, y = d['bmkg'].values, d['era5'].values
    n = len(d)
    r, p = stats.pearsonr(x, y)
    se = 1 / np.sqrt(n - 3)
    lo, hi = np.tanh([np.arctanh(r) - 1.96 * se, np.arctanh(r) + 1.96 * se])
    lr = stats.linregress(x, y)
    tcrit = stats.t.ppf(0.975, n - 2)
    res = dict(n=n,
               first_season='DJF %d/%02d' % (d.index.min(), (d.index.min() + 1) % 100),
               last_season='DJF %d/%02d' % (d.index.max(), (d.index.max() + 1) % 100),
               pearson_r=r, p_value=p, r_ci95_low=lo, r_ci95_high=hi,
               slope=lr.slope, slope_ci95=tcrit * lr.stderr, intercept=lr.intercept,
               bias_era5_minus_bmkg=float(np.mean(y - x)),
               rmse=float(np.sqrt(np.mean((y - x) ** 2))),
               mean_bmkg=float(x.mean()), mean_era5=float(y.mean()),
               kendall_tau=float(stats.kendalltau(x, y)[0]))
    res['rmse_pct_of_bmkg_mean'] = 100 * res['rmse'] / res['mean_bmkg']
    return d, res


# ---------- gambar ----------
def plot_scatter(d, res, outpng):
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 13})
    x, y = d['bmkg'].values, d['era5'].values
    lim = (min(x.min(), y.min()) - 10, max(x.max(), y.max()) + 10)
    fig, ax = plt.subplots(figsize=(6.6, 6.2), dpi=300)
    ax.plot(lim, lim, color='gray', lw=1.3, ls=':', label='1:1 line')
    xs = np.array(lim)
    ax.plot(xs, res['intercept'] + res['slope'] * xs, color='crimson', lw=2, label='Linear fit')
    ax.scatter(x, y, s=55, c='#66bb6a', edgecolor='#1b5e20', zorder=3, label='DJF seasonal mean')
    txt = (f"r = {res['pearson_r']:.2f} (95% CI {res['r_ci95_low']:.2f}–{res['r_ci95_high']:.2f})\n"
           f"p {'< 0.001' if res['p_value'] < 0.001 else '= %.3f' % res['p_value']}, n = {res['n']}\n"
           f"Slope = {res['slope']:.2f} ± {res['slope_ci95']:.2f}\n"
           f"Bias = {res['bias_era5_minus_bmkg']:+.1f} mm/month\n"
           f"RMSE = {res['rmse']:.1f} mm/month")
    ax.text(0.04, 0.96, txt, transform=ax.transAxes, va='top', fontsize=12,
            bbox=dict(boxstyle='round', fc='white', ec='gray'))
    ax.set_xlim(lim); ax.set_ylim(lim); ax.set_aspect('equal')
    ax.set_xlabel('BMKG in-situ observation (mm/month)', fontsize=14)
    ax.set_ylabel('ERA5 reanalysis (mm/month)', fontsize=14)
    ax.set_title('Evaluation of ERA5 DJF precipitation\nvs. BMKG in-situ, North Kalimantan', fontsize=14, fontweight='bold')
    ax.grid(alpha=0.3); ax.legend(loc='lower right', fontsize=11)
    fig.tight_layout()
    fig.savefig(outpng, dpi=300)
    fig.savefig(outpng.replace('.png', '.pdf'))
    plt.close(fig)


# ---------- main ----------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--era5', required=True)
    ap.add_argument('--bmkg', required=True)
    ap.add_argument('--out', default='hasil_fig2')
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    t, tp, lat, expver = load_era5_tp(a.era5)
    print('== CEK DATA ERA5 ==')
    print('Bulan pertama :', t[0].date(), '| bulan terakhir:', t[-1].date(), '| jumlah:', len(t))
    print('Semua tanggal tgl 1? ', bool((t.day == 1).all()))
    print('NaN di tp     :', int(np.isnan(tp).sum()))
    if expver is not None:
        v, c = np.unique(expver.astype(str), return_counts=True)
        print('expver        :', dict(zip(v, c)), '(1=ERA5 final, 5=ERA5T sementara)')
        e5 = np.where(expver.astype(str) == '5')[0]
        if len(e5): print('  ERA5T mulai  :', t[e5[0]].date(), 'sampai', t[e5[-1]].date())
    print('tp mentah (m/hari): min %.5f  maks %.5f  rata-rata %.5f' % (np.nanmin(tp), np.nanmax(tp), np.nanmean(tp)))

    mm = to_mm_month(t, tp)
    era5_ts = area_mean(mm, lat)
    print('Rata-rata curah hujan bulanan domain (mm/bulan): %.1f  <- harus sekitar 150-350 untuk Kaltara' % np.nanmean(era5_ts))

    era5 = djf_series(t, era5_ts)
    print('\n== JUMLAH MUSIM DJF LENGKAP ==')
    if len(era5) == 0:
        raise SystemExit('Tidak ada musim DJF lengkap terdeteksi. Cetak t[:5], t.dtype dan era5_ts[:5] lalu kirim ke chat.')
    print('Jumlah:', len(era5), '| pertama: DJF %d/%02d' % (era5.index[0], (era5.index[0] + 1) % 100),
          '| terakhir: DJF %d/%02d' % (era5.index[-1], (era5.index[-1] + 1) % 100))
    era5.rename('era5_djf_mm_month').to_csv(os.path.join(a.out, 'ERA5_DJF_regional_mean.csv'), index_label='year_of_december')

    bmkg = load_bmkg(a.bmkg)
    d, res = validate(era5, bmkg)
    print('\n== VALIDASI ERA5 vs BMKG ==')
    for k, v in res.items():
        print(f'{k:24s}', v if isinstance(v, (str, int)) else round(v, 4))
    pd.Series(res).to_csv(os.path.join(a.out, 'Validasi_ERA5_vs_BMKG.csv'), header=['value'])
    plot_scatter(d, res, os.path.join(a.out, 'Figure2_ERA5_vs_BMKG.png'))
    print('\nSelesai. Hasil ada di folder:', a.out)


if __name__ == '__main__':
    main()