import xarray as xr
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from factor_analyzer import Rotator

# =========================================================
# 1. PERSIAPAN DATA & EKSTRAKSI MUSIM (DJF)
# =========================================================
print("1. Membaca dan memproses data ERA5...")
ds = xr.open_dataset('avgad.nc')

# Konversi satuan tp dari meter/hari menjadi mm/bulan
tp = ds['tp'] * 1000 * 30 

# Memotong data sesuai periode riset (1955 - 2025)
tp = tp.sel(valid_time=slice('1955-01-01', '2025-02-28'))

# Filter musim DJF dan rata-ratakan per musim
tp_djf = tp.where(tp['valid_time'].dt.season == 'DJF', drop=True)
tp_seasonal = tp_djf.resample(valid_time='QS-DEC').mean()

# Membuang baris kuartal kosong (Maret, Juni, September)
tp_seasonal = tp_seasonal.dropna(dim='valid_time')

# =========================================================
# 2. STANDARISASI ANOMALI (Z-SCORE) BASELINE 1981-2010
# =========================================================
print("2. Menghitung anomali terstandardisasi (1981-2010)...")
# Ambil periode referensi WMO
baseline = tp_seasonal.sel(valid_time=slice('1981-01-01', '2010-12-31'))

# Hitung Rata-rata dan Standar Deviasi dari baseline
klimatologi = baseline.mean(dim='valid_time')
standar_deviasi = baseline.std(dim='valid_time')

# Rumus Z-score: (Data - Klimatologi) / Standar Deviasi
anomali_z = (tp_seasonal - klimatologi) / standar_deviasi

# Mengubah data 3D (Waktu, Lat, Lon) menjadi matriks 2D (Waktu, Grid Spasial) untuk PCA
waktu = anomali_z.shape[0]
lat_len = anomali_z.shape[1]
lon_len = anomali_z.shape[2]
jumlah_grid = lat_len * lon_len

# Matriks X: Baris = 71 Tahun, Kolom = 225 Titik Koordinat
X = anomali_z.values.reshape(waktu, jumlah_grid)
X = np.nan_to_num(X) # Membersihkan jika ada NaN kecil dari proses pembagian

# =========================================================
# 3. UNROTATED PCA (Komponen Utama Biasa)
# =========================================================
print("3. Menjalankan Unrotated PCA...")
# Inisiasi PCA untuk 4 komponen
pca = PCA(n_components=4)
pca.fit(X)

# Mengambil nilai sebelum rotasi
unrotated_scores = pca.transform(X)      # Shape: (71, 4)
unrotated_loadings = pca.components_     # Shape: (4, 225)
var_unrotated = pca.explained_variance_ratio_ * 100 # Persentase Varians

# =========================================================
# 4. ROTASI PROMAX (KAPPA = 3)
# =========================================================
print("4. Menerapkan Rotasi Promax (kappa=3)...")
# Inisiasi Rotator Promax
rotator = Rotator(method='promax', power=3)

# Rotator meminta input transpose matriks (Grid x Komponen), lalu dikembalikan lagi (Komponen x Grid)
promax_loadings_T = rotator.fit_transform(unrotated_loadings.T)
promax_loadings = promax_loadings_T.T 

# Menghitung Promax Scores menggunakan pseudo-inverse (Kondisi saat PCA Oblique)
promax_scores = X @ np.linalg.pinv(promax_loadings)

# =========================================================
# 5. MENGHITUNG VARIANCE EXPLAINED SESUDAH PROMAX
# =========================================================
print("5. Menghitung Variance Explained untuk naskah...\n")
total_variance = np.var(X)
var_promax = []

for i in range(4):
    # Rekonstruksi data per-komponen (Perkalian vektor Score x Loading)
    reconstructed_i = np.outer(promax_scores[:, i], promax_loadings[i, :])
    
    # Hitung varians dari hasil rekonstruksi
    var_i = np.var(reconstructed_i)
    
    # Hitung persentase
    pct = (var_i / total_variance) * 100
    var_promax.append(pct)

# =========================================================
# 6. OUTPUT TABEL UNTUK MANUSKRIP Q1
# =========================================================
print("="*60)
print("TABLE S1. Percentage of Variance Explained")
print("="*60)
print(f"{'Component':<12} | {'Unrotated Variance':<20} | {'Promax Variance'}")
print("-" * 60)
for i in range(4):
    print(f"PC{i+1:<10} | {var_unrotated[i]:>10.2f}%         | {var_promax[i]:>10.2f}%")
print("-" * 60)
print(f"{'Cumulative':<12} | {sum(var_unrotated):>10.2f}%         | {sum(var_promax):>10.2f}%")
print("="*60)