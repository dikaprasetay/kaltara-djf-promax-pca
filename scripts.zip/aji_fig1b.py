"""
Figure 1b (v2): klimatologi curah hujan DJF ERA5 (mm per bulan), DJF 1955/56-2024/25.

Perbedaan dari aji_fig1b.py lama:
  * hanya curah hujan (sirkulasi sudah ada di Figure 7);
  * satuan mm/bulan (tp x 1000 x jumlah hari sebenarnya), sama seperti Section 2.2 dan validasi;
  * hanya musim DJF lengkap 1955/56-2024/25 (n = 70), sesuai caption;
  * sel ERA5 digambar apa adanya (pcolormesh), tidak dihaluskan;
  * label Inggris, batas administrasi GADM (kabupaten tipis, provinsi tebal).

Jalankan dari folder newdata (validasi_era5_bmkg_fig2.py harus ada di folder yang sama):
  py aji_fig1b_v2.py
"""
import argparse
import os
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, MultipleLocator

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from validasi_era5_bmkg_fig2 import load_era5_tp, to_mm_month  # noqa: E402

FIRST_YEAR, LAST_YEAR = 1955, 2024   # tahun Desember: DJF 1955/56 ... DJF 2024/25


def djf_climatology(t, mm, first=FIRST_YEAR, last=LAST_YEAR):
    """Rata-rata DJF (3 bulan) tiap musim lengkap, lalu rata-rata antarmusim. mm: (T, Y, X)."""
    idx = {(int(y), int(m)): i for i, (y, m) in enumerate(zip(t.year, t.month))}
    seasons, used = [], []
    for y in range(first, last + 1):
        ks = [(y, 12), (y + 1, 1), (y + 1, 2)]
        if all(k in idx for k in ks):
            seasons.append(np.mean([mm[idx[k]] for k in ks], axis=0))
            used.append(y)
    if not seasons:
        raise SystemExit("Tidak ada musim DJF lengkap di rentang tahun yang diminta.")
    return np.mean(seasons, axis=0), used


def load_boundary(shp_dir):
    try:
        import geopandas as gpd
    except ImportError:
        print("geopandas tidak terpasang -> batas administrasi dilewati")
        return None
    for name in ("gadm41_IDN_2.shp", "gadm41_IDN_1.shp"):
        p = os.path.join(shp_dir, name)
        if os.path.exists(p):
            g = gpd.read_file(p)
            g = g[g["NAME_1"].str.upper() == "KALIMANTAN UTARA"]
            if len(g):
                return g
    print(f"Shapefile GADM tidak ditemukan di '{shp_dir}' -> batas administrasi dilewati")
    return None


def lon_fmt(x, _):
    return f"{x:g}°E"


def lat_fmt(y, _):
    return f"{y:g}°N"


def plot(clim, lon, lat, kab, out_prefix, dpi=300):
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11, "pdf.fonttype": 42})
    fig, ax = plt.subplots(figsize=(6.6, 6.0))
    vmin = np.floor(np.nanmin(clim) / 20) * 20
    vmax = np.ceil(np.nanmax(clim) / 20) * 20
    im = ax.pcolormesh(lon, lat, clim, cmap="YlGnBu", vmin=vmin, vmax=vmax, shading="auto",
                       rasterized=True, zorder=1)
    if kab is not None:
        kab.boundary.plot(ax=ax, color="0.35", linewidth=0.4, zorder=3)
        kab.dissolve().boundary.plot(ax=ax, color="k", linewidth=1.1, zorder=4)
    dx = abs(lon[1] - lon[0]) / 2
    dy = abs(lat[1] - lat[0]) / 2
    ax.set_xlim(lon.min() - dx, lon.max() + dx)
    ax.set_ylim(lat.min() - dy, lat.max() + dy)
    ax.set_aspect("equal", adjustable="box")
    ax.xaxis.set_major_locator(MultipleLocator(1))
    ax.yaxis.set_major_locator(MultipleLocator(1))
    ax.xaxis.set_major_formatter(FuncFormatter(lon_fmt))
    ax.yaxis.set_major_formatter(FuncFormatter(lat_fmt))
    ax.grid(color="white", lw=0.5, alpha=0.6)
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_title("(b)", loc="left", fontweight="bold")
    cb = fig.colorbar(im, ax=ax, shrink=0.82, pad=0.03)
    cb.set_label("DJF mean precipitation (mm month$^{-1}$)")
    for ext in ("png", "pdf"):
        out = f"{out_prefix}.{ext}"
        fig.savefig(out, dpi=dpi, bbox_inches="tight", facecolor="white")
        print("Tersimpan:", os.path.abspath(out))
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--era5", default="avgad.nc")
    ap.add_argument("--shp_dir", default="gadm41_IDN_shp")
    ap.add_argument("--out", default="Figure1b_DJF_Rainfall_Climatology")
    a = ap.parse_args()

    import xarray as xr
    lon = xr.open_dataset(a.era5)["longitude"].values
    t, tp, lat, _ = load_era5_tp(a.era5)
    mm = to_mm_month(t, tp)
    clim, used = djf_climatology(t, mm)
    print(f"Musim DJF dipakai: {len(used)} (DJF {used[0]}/{str(used[0] + 1)[2:]} - "
          f"DJF {used[-1]}/{str(used[-1] + 1)[2:]})" + ("" if len(used) == 70 else "  <- BUKAN 70, cek data!"))

    w = np.cos(np.deg2rad(lat))[:, None] * np.ones((1, lon.size))
    ok = np.isfinite(clim)
    print(f"Rata-rata domain (bobot cos lat): {np.sum(clim[ok] * w[ok]) / np.sum(w[ok]):.1f} mm/bulan")
    imax = np.unravel_index(np.nanargmax(clim), clim.shape)
    imin = np.unravel_index(np.nanargmin(clim), clim.shape)
    print(f"Maksimum {clim[imax]:.0f} mm/bulan di {lat[imax[0]]:.2f}N, {lon[imax[1]]:.2f}E | "
          f"minimum {clim[imin]:.0f} mm/bulan di {lat[imin[0]]:.2f}N, {lon[imin[1]]:.2f}E")

    plot(clim, lon, lat, load_boundary(a.shp_dir), a.out)


if __name__ == "__main__":
    main()
