import os
import xarray as xr
import numpy as np
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from scipy.interpolate import RegularGridInterpolator

# ==============================================================================
# 1. PATH DATA DAN PERSIAPAN DATASET REGIONAL
# ==============================================================================
shp_dir = r"C:\Users\user\Documents\data_jurnal\newdata\gadm41_IDN_shp"
path_kab = os.path.join(shp_dir, "gadm41_IDN_2.shp")

print("--- Membaca Batas Administrasi Kaltara untuk Overlay ---")
gdf_kab = gpd.read_file(path_kab)
kaltara_shp = gdf_kab[gdf_kab['NAME_1'].str.upper() == 'KALIMANTAN UTARA'].copy()

print("--- Membaca File Hasil Antara: PC Scores CSV ---")
df_pc = pd.read_csv('PC_scores_DJF_1955_2025.csv', index_col='Year')

print("--- Memproses Dataset Curah Hujan ERA5 (avgad.nc) ---")
ds_ad = xr.open_dataset('avgad.nc')
if 'expver' in ds_ad.coords or 'expver' in ds_ad.data_vars:
    ds_ad = ds_ad.drop_vars('expver', errors='ignore')

# Mengunci orientasi koordinat grid (Ascending untuk standardisasi interpolasi)
ds_ad = ds_ad.sortby('latitude', ascending=True)
ds_ad = ds_ad.sortby('longitude', ascending=True)

time_coords = ds_ad['valid_time'].values
if isinstance(time_coords, np.ndarray) and np.issubdtype(time_coords.dtype, np.datetime64):
    time_idx = pd.DatetimeIndex(time_coords)
else:
    time_idx = pd.to_datetime(time_coords)

ds_ad.coords['year'] = ('valid_time', time_idx.year)
ds_ad.coords['month'] = ('valid_time', time_idx.month)

# ==============================================================================
# 2. EKSTRAKSI DAN HITUNG MATRIKS ANOMALI MUSIM DJF TAHUNAN (1955 - 2025)
# ==============================================================================
print("--- Perhitungan Matriks Anomali Curah Hujan Musiman ---")
years_range = np.arange(1955, 2026)
n_years = len(years_range)

lon_orig = ds_ad['longitude'].values
lat_orig = ds_ad['latitude'].values
n_lat, n_lon = len(lat_orig), len(lon_orig)

djf_yearly_rain = np.zeros((n_years, n_lat, n_lon))

for idx, yr in enumerate(years_range):
    ds_dec = ds_ad.sel(valid_time=(ds_ad['month'] == 12) & (ds_ad['year'] == yr - 1))
    ds_jan = ds_ad.sel(valid_time=(ds_ad['month'] == 1) & (ds_ad['year'] == yr))
    ds_feb = ds_ad.sel(valid_time=(ds_ad['month'] == 2) & (ds_ad['year'] == yr))
    
    m_slices = []
    if len(ds_dec['valid_time']) > 0: m_slices.append(ds_dec['tp'].values * 1000.0)
    if len(ds_jan['valid_time']) > 0: m_slices.append(ds_jan['tp'].values * 1000.0)
    if len(ds_feb['valid_time']) > 0: m_slices.append(ds_feb['tp'].values * 1000.0)
    
    if len(m_slices) > 0:
        djf_yearly_rain[idx, :, :] = np.mean(np.concatenate(m_slices, axis=0), axis=0)
    else:
        djf_yearly_rain[idx, :, :] = np.nan

if np.isnan(djf_yearly_rain).any():
    col_mean = np.nanmean(djf_yearly_rain, axis=0)
    inds = np.where(np.isnan(djf_yearly_rain))
    djf_yearly_rain[inds] = np.take(col_mean, inds[1:])

climatology_djf = np.mean(djf_yearly_rain, axis=0)
djf_anomaly = djf_yearly_rain - climatology_djf

# ==============================================================================
# 3. PENGELOMPOKAN KLUSTER FASE EKSTREM PC SCORES DAN KOMPOSIT DATA
# ==============================================================================
print("--- Mengklasifikasikan Tahun Berdasarkan Fase PC Scores & Hitung Komposit ---")
extent = [114.3, 118.2, 0.8, 4.7]
lon_high = np.linspace(extent[0], extent[1], 500)
lat_high = np.linspace(extent[2], extent[3], 500)
lon_mesh, lat_mesh = np.meshgrid(lon_high, lat_high)

# Threshold nilai ekstrem PC sesuai acuan
threshold = 0.5
composite_maps = {}

for pc_name in ['PC1', 'PC2', 'PC3', 'PC4']:
    scores = df_pc[pc_name].values
    
    pos_years_idx = np.where(scores >= threshold)[0]
    neg_years_idx = np.where(scores <= -threshold)[0]
    
    if len(pos_years_idx) > 0:
        pos_comp_raw = np.mean(djf_anomaly[pos_years_idx, :, :], axis=0)
    else:
        pos_comp_raw = np.zeros((n_lat, n_lon))
        
    if len(neg_years_idx) > 0:
        neg_comp_raw = np.mean(djf_anomaly[neg_years_idx, :, :], axis=0)
    else:
        neg_comp_raw = np.zeros((n_lat, n_lon))
        
    interp_pos = RegularGridInterpolator((lat_orig, lon_orig), pos_comp_raw, bounds_error=False, fill_value=0.0)
    interp_neg = RegularGridInterpolator((lat_orig, lon_orig), neg_comp_raw, bounds_error=False, fill_value=0.0)
    
    grid_points = np.array([lat_mesh.flatten(), lon_mesh.flatten()]).T
    
    composite_maps[f'{pc_name}_pos'] = interp_pos(grid_points).reshape(500, 500)
    composite_maps[f'{pc_name}_neg'] = interp_neg(grid_points).reshape(500, 500)

# ==============================================================================
# 4. VISUALISASI SENSITIF WARNA TINGGI (MATRIKS 4x2 HIGH-RES REVISI)
# ==============================================================================
print("--- Plotting Kartografi Komposit Lebih Berwarna dan Sensitif ---")
fig, axs = plt.subplots(4, 2, figsize=(16, 28), dpi=300)

# REVISI OPTIMASI: Sumbu skala dipersempit menjadi -40 hingga +40 mm agar kontur warna 
# menjadi sangat sensitif, tajam, dan tidak pudar/putih polos seperti sebelumnya.
vmin, vmax = -40.0, 40.0
levels = np.linspace(vmin, vmax, 21) # Pembagian 21 interval warna yang rapat dan kontras

row_pcs = ['PC1', 'PC2', 'PC3', 'PC4']
letters_pos = ['a', 'c', 'e', 'g']
letters_neg = ['b', 'd', 'f', 'h']

for i, pc in enumerate(row_pcs):
    # Kolom 1: Fase Positif
    ax_pos = axs[i, 0]
    data_pos = composite_maps[f'{pc}_pos']
    im = ax_pos.contourf(lon_mesh, lat_mesh, data_pos, levels=levels, cmap='RdBu_r', extend='both', zorder=1)
    kaltara_shp.plot(ax=ax_pos, facecolor='none', edgecolor='black', linewidth=1.4, zorder=2)
    ax_pos.set_aspect('equal', adjustable='box')
    ax_pos.set_xlim(extent[0], extent[1])
    ax_pos.set_ylim(extent[2], extent[3])
    ax_pos.grid(True, linestyle=':', color='gray', alpha=0.5, zorder=3)
    ax_pos.tick_params(labelsize=10)
    ax_pos.set_ylabel(f'{pc}\n\nLintang / Latitude (°N)', fontsize=12, fontweight='bold', labelpad=6)
    if i == 3: ax_pos.set_xlabel('Bujur / Longitude (°E)', fontsize=11, fontweight='bold', labelpad=6)
    
    # Keterangan Judul diperjelas kaitan fisis angka PC-nya
    ax_pos.set_title(f'Positive Phase Anomaly (When {pc} $\geq$ +0.5)', fontsize=12, fontweight='bold', pad=10)
    ax_pos.text(0.04, 0.93, f'({letters_pos[i]})', transform=ax_pos.transAxes, fontsize=16, fontweight='bold', zorder=4)
    
    # Kolom 2: Fase Negatif
    ax_neg = axs[i, 1]
    data_neg = composite_maps[f'{pc}_neg']
    ax_neg.contourf(lon_mesh, lat_mesh, data_neg, levels=levels, cmap='RdBu_r', extend='both', zorder=1)
    kaltara_shp.plot(ax=ax_neg, facecolor='none', edgecolor='black', linewidth=1.4, zorder=2)
    ax_neg.set_aspect('equal', adjustable='box')
    ax_neg.set_xlim(extent[0], extent[1])
    ax_neg.set_ylim(extent[2], extent[3])
    ax_neg.grid(True, linestyle=':', color='gray', alpha=0.5, zorder=3)
    ax_neg.tick_params(labelsize=10)
    if i == 3: ax_neg.set_xlabel('Bujur / Longitude (°E)', fontsize=11, fontweight='bold', labelpad=6)
    
    # Keterangan Judul diperjelas kaitan fisis angka PC-nya
    ax_neg.set_title(f'Negative Phase Anomaly (When {pc} $\leq$ -0.5)', fontsize=12, fontweight='bold', pad=10)
    ax_neg.text(0.04, 0.93, f'({letters_neg[i]})', transform=ax_neg.transAxes, fontsize=16, fontweight='bold', zorder=4)

# REVISI COLORBAR: Desain bar dibuat dinamis, rapat, dan label keterangan diubah agar informatif 
# mengikat fisis besaran nilai komposit anomali terhadap skor PC.
cbar_ax = fig.add_axes([0.25, 0.06, 0.50, 0.012])
cbar = fig.colorbar(im, cax=cbar_ax, orientation='horizontal')
cbar.set_label('Composite Rainfall Anomaly Magnitude (mm) relative to Climatology', fontsize=12, fontweight='bold', labelpad=8)
cbar.ax.tick_params(labelsize=10)

plt.subplots_adjust(bottom=0.09, hspace=0.25, wspace=0.12)
output_filename = 'Figure_3_Composite_Anomalies_DJF_Sensitif.png'
plt.savefig(output_filename, bbox_inches='tight', dpi=300)
plt.close()

print(f"--- SELESAI SEMPURNA: Figure Komposit Sensitif Warna '{output_filename}' Berhasil Disimpan ---")