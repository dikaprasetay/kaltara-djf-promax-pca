# =====================================================
# FIGURE 8 (v3) - TREN BULANAN HUJAN: DESEMBER, JANUARI, FEBRUARI
# 70 musim DJF (Des 1955 - Feb 2025). Satuan: mm/bulan per dekade.
#
# Perubahan dibanding versi sebelumnya (Reviewer 3, Minor 18; juga Reviewer 1, butir 1.19):
#   1. Besaran tren = lereng Sen (mm/bulan per dekade), bukan koefisien regresi terstandar.
#      Sebelumnya warna = OLS terstandar tetapi uji = Mann-Kendall -> tidak konsisten dengan Metode.
#   2. Uji signifikansi = TFPW-Mann-Kendall (Yue et al. 2002), sama dengan Metode analisis PC.
#   3. Koreksi uji berganda Benjamini-Hochberg (FDR 5%) di seluruh sel grid per bulan.
#   4. Sel signifikan diberi titik (stippling), bukan "warna pudar" -> mudah dibaca.
#   5. Konversi satuan benar: tp ERA5 monthly means (avgad) = m/hari -> x1000 x jumlah hari bulan.
#   6. Tahun tiap bulan diselaraskan dengan musim DJF: Des tahun y bersama Jan-Feb tahun y+1
#      (y = 1955..2024, n = 70).
#   7. Grid asli 0,25 derajat digambar apa adanya (pcolormesh), tanpa interpolasi 500x500 yang
#      memberi kesan resolusi lebih halus daripada datanya. Gaya sama dengan Fig. 3-5.
#
# Jalankan:  py aji_fig10_v3.py
# Butuh: numpy, pandas, xarray, geopandas, matplotlib, scipy, pymannkendall
# =====================================================
import os
import warnings
import numpy as np
import pandas as pd
import xarray as xr
import geopandas as gpd
import matplotlib.pyplot as plt
import pymannkendall as mk

warnings.filterwarnings("ignore")

BASE = r"C:\Users\user\Documents\data_jurnal\newdata"
nc_file = os.path.join(BASE, "avgad.nc")
shp_file = os.path.join(BASE, "gadm41_IDN_shp", "gadm41_IDN_2.shp")
out_png = os.path.join(BASE, "Figure8_Monthly_Trends_v3.png")
out_pdf = os.path.join(BASE, "Figure8_Monthly_Trends_v3.pdf")
out_csv = os.path.join(BASE, "Figure8_statistik_v3.csv")
if not os.path.exists(nc_file):                         # untuk uji di folder lain
    nc_file, shp_file = "avgad.nc", "kaltara_test.shp"
    out_png, out_pdf, out_csv = "Figure8_v3.png", "Figure8_v3.pdf", "Figure8_statistik_v3.csv"

SEASON_FIRST, SEASON_LAST = 1955, 2024        # tahun DESEMBER -> 70 musim
ALPHA = 0.05


# ---------------- data ----------------
def bh_fdr_mask(p, alpha=ALPHA):
    p = np.asarray(p, float)
    ok = np.isfinite(p)
    out = np.zeros(p.shape, bool)
    pv = p[ok]
    if pv.size == 0:
        return out
    order = np.argsort(pv)
    thr = alpha * (np.arange(1, pv.size + 1) / pv.size)
    below = pv[order] <= thr
    sig = np.zeros(pv.size, bool)
    if below.any():
        sig[order[: np.where(below)[0].max() + 1]] = True
    out[ok] = sig
    return out


ds = xr.open_dataset(nc_file)
ds = ds.drop_vars("expver", errors="ignore")
ds = ds.sortby("latitude").sortby("longitude")
t = pd.DatetimeIndex(ds["valid_time"].values)
lat, lon = ds["latitude"].values, ds["longitude"].values
tp = ds["tp"].values.astype("float64")                   # m/hari (rata-rata akumulasi harian)
mm_month = tp * 1000.0 * np.asarray(t.days_in_month)[:, None, None]


def monthly_series(month):
    """Array (musim, lat, lon) untuk satu bulan; indeks musim = tahun Desember."""
    sel = np.where(t.month == month)[0]
    season = t.year[sel] - (0 if month == 12 else 1)
    keep = (season >= SEASON_FIRST) & (season <= SEASON_LAST)
    sel, season = sel[keep], season[keep]
    order = np.argsort(season)
    sel, season = sel[order], season[order]
    exp = np.arange(SEASON_FIRST, SEASON_LAST + 1)
    if not np.array_equal(season, exp):
        raise SystemExit(f"Bulan {month}: musim tidak lengkap ({len(season)} dari {len(exp)}).")
    return mm_month[sel]


def cell_trends(arr):
    ny, nx = arr.shape[1:]
    slope = np.full((ny, nx), np.nan)
    p = np.full((ny, nx), np.nan)
    for i in range(ny):
        for j in range(nx):
            y = arr[:, i, j]
            if not np.isfinite(y).all() or np.ptp(y) == 0:
                continue
            r = mk.trend_free_pre_whitening_modification_test(y)
            slope[i, j] = r.slope * 10.0                     # per tahun -> per dekade
            p[i, j] = r.p
    return slope, p


names = {12: "December", 1: "January", 2: "February"}
res, rows = {}, []
for m in (12, 1, 2):
    arr = monthly_series(m)
    s, p = cell_trends(arr)
    sig = bh_fdr_mask(p)
    reg = arr.mean(axis=(1, 2))
    rr = mk.trend_free_pre_whitening_modification_test(reg)
    res[m] = (s, p, sig)
    rows.append(dict(month=names[m], n=arr.shape[0],
                     regional_mean_mm_month=reg.mean(),
                     regional_sen_mm_month_per_decade=rr.slope * 10, regional_tfpw_p=rr.p,
                     cells_total=int(np.isfinite(s).sum()),
                     cells_sig_raw_p005=int((p < ALPHA).sum()),
                     cells_sig_FDR=int(sig.sum()),
                     max_pos=np.nanmax(s), min_neg=np.nanmin(s)))
    print(rows[-1])
pd.DataFrame(rows).round(3).to_csv(out_csv, index=False)

# ---------------- gambar ----------------
kab = gpd.read_file(shp_file)
kaltara = kab[kab["NAME_1"].str.upper() == "KALIMANTAN UTARA"]

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 12, "axes.titlesize": 13,
                     "axes.labelsize": 12, "xtick.labelsize": 11, "ytick.labelsize": 11})
vmax = float(np.ceil(np.nanpercentile(np.abs(np.concatenate([res[m][0].ravel() for m in res])), 99) / 2.5) * 2.5)
vmax = max(vmax, 2.5)
fig, axes = plt.subplots(1, 3, figsize=(15, 5.6), sharey=True, constrained_layout=True)
LON, LAT = np.meshgrid(lon, lat)
for ax, m, lt in zip(axes, (12, 1, 2), "abc"):
    s, p, sig = res[m]
    im = ax.pcolormesh(lon, lat, s, cmap="RdBu_r", vmin=-vmax, vmax=vmax, shading="nearest")
    ax.scatter(LON[sig], LAT[sig], s=16, c="k", marker=".", linewidths=0)
    kaltara.boundary.plot(ax=ax, color="k", linewidth=0.9)
    ax.set_xlim(lon.min() - 0.125, lon.max() + 0.125)
    ax.set_ylim(lat.min() - 0.125, lat.max() + 0.125)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("Longitude (°E)")
    ax.set_ylabel("Latitude (°N)" if m == 12 else "")
    ax.grid(True, ls=":", color="gray", alpha=0.4)
    ax.set_title(f"({lt}) {names[m]}", loc="left", fontweight="bold")
cb = fig.colorbar(im, ax=axes, orientation="horizontal", fraction=0.05, pad=0.03, aspect=50)
cb.set_label("Sen slope of ERA5 monthly precipitation (mm month$^{-1}$ per decade); "
             "dots = TFPW Mann–Kendall significant, FDR 5%")
fig.suptitle("Trends of December, January and February precipitation over North Kalimantan, "
             "DJF 1955/56–2024/25 (n = 70)", fontsize=13, fontweight="bold")
fig.savefig(out_png, dpi=300, facecolor="white")
fig.savefig(out_pdf)
print("Saved:", out_png, out_pdf, out_csv)
