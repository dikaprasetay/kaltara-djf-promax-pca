"""
Peta korelasi spasial: skor PC Promax (DJF, Kalimantan Utara) vs anomali SST global (DJF)
Figure 6 (v3) -- PC1 (a), PC2 (b), PC3 (c), PC4 (d)
Stippling = signifikan pada alpha = 0.05 setelah kontrol FDR (Benjamini-Hochberg, Wilks 2016),
uji korelasi memakai ukuran sampel efektif neff = n(1-rho)/(1+rho) (Bretherton et al. 1999),
sama seperti Section 2.5 naskah.

Cara pakai (di folder newdata, env_sst aktif):
    python aji_fig_sst_corr.py
Kalau nama variabel/file berbeda, ubah bagian KONFIGURASI di bawah.
Dependensi: numpy, pandas, xarray, netCDF4, scipy, matplotlib
"""
import os
import numpy as np
import pandas as pd
import xarray as xr
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, MultipleLocator
from scipy import stats

# =========================== KONFIGURASI ===========================
SST_FILE = "sstworld.nc"
PC_FILE = os.path.join("hasil_pca", "pc_scores_promax_v2.csv")
OUT_PREFIX = "Figure6_SST_Correlation_PC1_PC4_FDR"

SST_VAR = None          # None = deteksi otomatis (sst / analysed_sst / ...)
LAT_RANGE = (-40, 40)   # batas lintang peta
LON_RANGE = (30, 290)   # batas bujur (0-360)

# Label tahun pada file PC: 1956 = DJF Des-1955 + Jan-Feb 1956 (tahun Jan/Feb).
# Jika di PCA Anda 1956 = Des-1956 + Jan-Feb 1957, ganti ke "dec".
YEAR_LABEL = "jan"

# GANTI sesuai output PCA terbaru (promax_v2). Nilai di bawah diambil dari gambar lama.
EXPL_VAR = {"PC1": 72.02, "PC2": 9.02, "PC3": 5.19, "PC4": 2.61}

ALPHA = 0.05
DETREND = False          # True = hilangkan tren linear dari PC dan SST sebelum korelasi
USE_FDR = True           # True = kontrol FDR (Benjamini-Hochberg), False = uji titik biasa
USE_NEFF = True          # True = df dari ukuran sampel efektif (Bretherton et al. 1999), False = df = n-2
SHARED_COLORBAR = False  # True = satu skala warna (+-vmax) untuk keempat panel
MARK_STUDY_AREA = True   # bintang di Kalimantan Utara
STUDY_AREA = (3.0, 116.5)  # (lat, lon)
DPI = 300

# Peta dasar GADM (Indonesia). Butuh geopandas; kalau tidak ada, dilewati otomatis.
USE_GADM = True
GADM_DIR = "gadm41_IDN_shp"   # folder berisi gadm41_IDN_0.shp dan gadm41_IDN_1.shp
HIGHLIGHT_KALTARA = True      # garis merah di batas Kalimantan Utara (menggantikan bintang)
LAND_COLOR = "#d9d9d9"
# ===================================================================

mpl.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10,
    "axes.linewidth": 0.8,
    "hatch.color": "0.15",
    "hatch.linewidth": 0.45,
    "pdf.fonttype": 42,
    "savefig.bbox": "tight",
})


def find_name(ds, candidates, kind):
    for c in candidates:
        if c in ds.variables or c in ds.dims:
            return c
    raise KeyError(f"Tidak menemukan {kind}. Isi file: {list(ds.variables)}")


def load_sst():
    ds = xr.open_dataset(SST_FILE)
    tname = find_name(ds, ["time", "valid_time", "date", "T"], "koordinat waktu")
    lat_n = find_name(ds, ["latitude", "lat", "Y"], "lintang")
    lon_n = find_name(ds, ["longitude", "lon", "X"], "bujur")
    var = SST_VAR or find_name(
        ds, ["sst", "analysed_sst", "SST", "sea_surface_temperature", "to", "thetao", "t2m"], "variabel SST")
    da = ds[var]
    # buang dimensi ekstra (mis. level/expver) bila ada
    for d in list(da.dims):
        if d not in (tname, lat_n, lon_n):
            da = da.isel({d: 0}, drop=True) if da.sizes[d] == 1 else da.mean(d)
    da = da.rename({tname: "time", lat_n: "lat", lon_n: "lon"})
    # bujur -> 0..360, lintang menaik
    da = da.assign_coords(lon=(da.lon % 360)).sortby("lon").sortby("lat")
    da = da.sel(lat=slice(*LAT_RANGE), lon=slice(*LON_RANGE))
    print(f"SST: var='{var}', {str(da.time.values[0])[:7]} s.d. {str(da.time.values[-1])[:7]}, "
          f"grid {da.sizes['lat']}x{da.sizes['lon']}")
    return da.load()


def djf_mean(da):
    """Rata-rata DJF; tahun musim = tahun Jan/Feb (atau Des), hanya musim lengkap (3 bulan)."""
    t = pd.DatetimeIndex(da.time.values)
    m = t.month
    keep = np.isin(m, [12, 1, 2])
    da = da.isel(time=np.where(keep)[0])
    t, m = t[keep], m[keep]
    if YEAR_LABEL == "jan":
        sy = t.year + (m == 12).astype(int)
    else:
        sy = t.year - (m != 12).astype(int)
    da = da.assign_coords(season=("time", sy))
    cnt = pd.Series(sy).value_counts()
    full = cnt[cnt == 3].index.values
    djf = da.groupby("season").mean("time", skipna=False)
    djf = djf.sel(season=[y for y in djf.season.values if y in full])
    return djf


def detrend_1d(x, t):
    A = np.vstack([t, np.ones_like(t)]).T
    coef, *_ = np.linalg.lstsq(A, x, rcond=None)
    return x - A @ coef


def lag1(a):
    """Autokorelasi lag-1 sepanjang sumbu waktu (axis 0). a: (T, ...) -> (...)."""
    a0 = a - a.mean(0)
    with np.errstate(divide="ignore", invalid="ignore"):
        return (a0[1:] * a0[:-1]).sum(0) / (a0 ** 2).sum(0)


def corr_map(X, y):
    """Korelasi Pearson tiap grid. X: (T, Y, X), y: (T,). Return r, p.
    Jika USE_NEFF: neff = n(1-rho)/(1+rho), rho = r1(x) * r1(y), dibatasi 3 <= neff <= n,
    dan p dari distribusi t dengan neff-2 derajat bebas (sama seperti Section 2.5)."""
    n = len(y)
    valid = np.isfinite(X).all(axis=0)
    Xf = np.where(valid, X, 0.0)
    Xa = Xf - Xf.mean(0)
    ya = y - y.mean()
    num = (Xa * ya[:, None, None]).sum(0)
    den = np.sqrt((Xa ** 2).sum(0)) * np.sqrt((ya ** 2).sum())
    with np.errstate(divide="ignore", invalid="ignore"):
        r = num / den
        if USE_NEFF:
            rho = lag1(Xf) * lag1(y)
            neff = np.clip(n * (1 - rho) / (1 + rho), 3.0, n)
            df = neff - 2
        else:
            neff = np.full(r.shape, float(n))
            df = n - 2
        tval = r * np.sqrt(df / (1 - r ** 2))
    p = 2 * stats.t.sf(np.abs(tval), df)
    r[~valid] = np.nan
    p[~valid] = np.nan
    corr_map.last_neff = np.where(valid, neff, np.nan)
    return r, p


def significance_mask(p):
    ok = np.isfinite(p)
    if not USE_FDR:
        return ok & (p <= ALPHA)
    ps = np.sort(p[ok])
    k = np.arange(1, ps.size + 1)
    below = ps <= (k / ps.size) * ALPHA
    p_fdr = ps[np.where(below)[0].max()] if below.any() else 0.0
    return ok & (p <= p_fdr)


def load_gadm():
    """Baca GADM Indonesia (level 0 = negara, level 1 = provinsi). Return (land, kaltara) atau (None, None)."""
    if not USE_GADM:
        return None, None
    try:
        import geopandas as gpd
    except ImportError:
        print("geopandas tidak terpasang -> peta GADM dilewati (pip install geopandas)")
        return None, None
    here = os.path.dirname(os.path.abspath(__file__))
    folder = next((d for d in (GADM_DIR, os.path.join(here, GADM_DIR)) if os.path.isdir(d)), None)
    if folder is None:
        print(f"Folder GADM '{GADM_DIR}' tidak ditemukan -> peta GADM dilewati")
        return None, None
    bbox = (LON_RANGE[0], LAT_RANGE[0], 180, LAT_RANGE[1])
    land = kaltara = None
    p0 = os.path.join(folder, "gadm41_IDN_0.shp")
    if os.path.exists(p0):
        land = gpd.read_file(p0, bbox=bbox)
        land["geometry"] = land.geometry.simplify(0.01)
    else:
        print("gadm41_IDN_0.shp tidak ada")
    p1 = os.path.join(folder, "gadm41_IDN_1.shp")
    if HIGHLIGHT_KALTARA and os.path.exists(p1):
        prov = gpd.read_file(p1)
        key = prov["NAME_1"].str.lower().str.replace(" ", "", regex=False)
        kaltara = prov[key.str.contains("kalimantanutara")].copy()
        if kaltara.empty:
            print("Provinsi Kalimantan Utara tidak ditemukan di NAME_1; nilai yang ada:",
                  sorted(prov["NAME_1"].unique())[:40])
            kaltara = None
        else:
            kaltara["geometry"] = kaltara.geometry.simplify(0.005)
    return land, kaltara


def lon_fmt(x, _):
    x = x % 360
    if x == 0 or x == 180:
        return f"{int(x)}°"
    return f"{int(x)}°E" if x < 180 else f"{int(360 - x)}°W"


def lat_fmt(y, _):
    return "0°" if y == 0 else (f"{int(abs(y))}°N" if y > 0 else f"{int(abs(y))}°S")


def main():
    # ---- data PC ----
    here = os.path.dirname(os.path.abspath(__file__))
    cands = [PC_FILE, os.path.join(here, PC_FILE),
             os.path.basename(PC_FILE), os.path.join(here, os.path.basename(PC_FILE))]
    pc_path = next((c for c in cands if os.path.exists(c)), None)
    if pc_path is None:
        raise FileNotFoundError(f"File PC tidak ditemukan. Sudah dicari di: {cands}")
    print("File PC:", os.path.abspath(pc_path))
    pcs = pd.read_csv(pc_path).set_index("Year")
    pcs = pcs[["PC1", "PC2", "PC3", "PC4"]]
    # ---- data SST -> DJF -> anomali ----
    djf = djf_mean(load_sst())
    years = np.intersect1d(pcs.index.values, djf.season.values)
    print(f"Tahun dipakai: {years.min()}-{years.max()} (N = {len(years)}; PC = {len(pcs)})")
    if len(years) < len(pcs):
        miss = sorted(set(pcs.index) - set(years))
        print(f"  PERINGATAN: tahun PC tanpa data SST DJF lengkap: {miss}")
    djf = djf.sel(season=years)
    anom = djf - djf.mean("season")
    X = anom.values.astype(float)
    t = years.astype(float)
    lon, lat = anom.lon.values, anom.lat.values

    results = {}
    for pc in pcs.columns:
        y = pcs.loc[years, pc].values.astype(float)
        Xp = X
        if DETREND:
            y = detrend_1d(y, t)
            Xp = np.apply_along_axis(detrend_1d, 0, np.where(np.isfinite(X), X, 0.0), t)
            Xp = np.where(np.isfinite(X), Xp, np.nan)
        r, p = corr_map(Xp, y)
        results[pc] = (r, significance_mask(p))
        ne = corr_map.last_neff
        print(f"  {pc}: neff median/min = {np.nanmedian(ne):.1f}/{np.nanmin(ne):.1f}; r min/max = {np.nanmin(r):+.2f}/{np.nanmax(r):+.2f}, "
              f"signifikan {100 * results[pc][1].sum() / np.isfinite(r).sum():.1f}% grid")

    # ---- plot ----
    fig, axes = plt.subplots(4, 1, figsize=(9.5, 13.2), sharex=True)
    cmap = plt.get_cmap("RdBu_r").copy()
    cmap.set_bad("#d9d9d9")  # daratan / es = abu-abu
    land_gdf, kaltara_gdf = load_gadm()
    vmax_all = np.ceil(max(np.nanmax(np.abs(r)) for r, _ in results.values()) * 10) / 10

    for ax, pc, tag in zip(axes, results, "abcd"):
        r, sig = results[pc]
        vmax = vmax_all if SHARED_COLORBAR else max(0.2, np.ceil(np.nanmax(np.abs(r)) * 20) / 20)
        im = ax.pcolormesh(lon, lat, np.ma.masked_invalid(r), cmap=cmap, vmin=-vmax, vmax=vmax,
                           shading="auto", rasterized=True, zorder=1)
        ax.contourf(lon, lat, sig.astype(float), levels=[0.5, 1.5], colors="none",
                    hatches=["......"], zorder=2)
        # garis pantai dari mask daratan pada grid SST (seluruh dunia)
        ax.contour(lon, lat, (~np.isfinite(r)).astype(float), levels=[0.5],
                   colors="0.25", linewidths=0.4, zorder=3)
        # poligon daratan Indonesia (GADM) di atas semuanya agar pantai tajam
        if land_gdf is not None:
            land_gdf.plot(ax=ax, facecolor=LAND_COLOR, edgecolor="0.25", linewidth=0.35, zorder=4)
        has_kaltara = kaltara_gdf is not None
        if has_kaltara:
            kaltara_gdf.plot(ax=ax, facecolor="none", edgecolor="#d62728", linewidth=0.9, zorder=5)
        ax.set_xlim(lon.min(), lon.max())
        ax.set_ylim(lat.min(), lat.max())
        ax.set_aspect("equal", adjustable="box")
        ax.xaxis.set_major_locator(MultipleLocator(30))
        ax.yaxis.set_major_locator(MultipleLocator(20))
        ax.xaxis.set_major_formatter(FuncFormatter(lon_fmt))
        ax.yaxis.set_major_formatter(FuncFormatter(lat_fmt))
        ax.grid(color="white", lw=0.5, alpha=0.7)
        ax.set_axisbelow(False)
        ax.tick_params(length=3, labelsize=9)
        if MARK_STUDY_AREA and not has_kaltara:
            ax.plot(STUDY_AREA[1], STUDY_AREA[0], marker="*", ms=11, mfc="gold", mec="k", mew=0.8, zorder=6)
        ax.set_title(f"({tag})  {pc}  |  Explained variance: {EXPL_VAR[pc]:.2f}%",
                     loc="left", fontsize=11, fontweight="bold", pad=6)
        if not SHARED_COLORBAR:
            cb = fig.colorbar(im, ax=ax, fraction=0.025, pad=0.015, aspect=22)
            cb.set_label("Pearson r", fontsize=9)
            cb.ax.tick_params(labelsize=8)
            cb.outline.set_linewidth(0.6)
    if SHARED_COLORBAR:
        cb = fig.colorbar(im, ax=axes, fraction=0.02, pad=0.015, aspect=45)
        cb.set_label("Pearson r", fontsize=9)
        cb.ax.tick_params(labelsize=8)

    axes[-1].set_xlabel("Longitude", fontsize=10)
    for ax in axes:
        ax.set_ylabel("Latitude", fontsize=10)
    fig.subplots_adjust(hspace=0.28)

    for ext in ("png", "pdf"):
        out = f"{OUT_PREFIX}.{ext}"
        fig.savefig(out, dpi=DPI)
        print("Tersimpan:", os.path.abspath(out))


if __name__ == "__main__":
    main()