# =====================================================
# FIGURE 7 (v3) - SKOR PC + TREN (SEN/TFPW) + TITIK UBAH PETTITT
# 70 musim DJF (1956-2025; tahun = tahun JANUARI musim DJF)
#
# Perubahan dibanding versi sebelumnya (menjawab Reviewer 3, Minor 17 & 18):
#   1. Garis tren = lereng Sen, p = TFPW-Mann-Kendall (sama dengan Metode), BUKAN OLS.
#   2. Titik ubah Pettitt: tahun terakhir rezim lama dan tahun pertama rezim baru
#      dibedakan secara eksplisit; garis digambar di antara keduanya.
#   3. Ketidakpastian titik ubah: rentang 90% dari block bootstrap (blok 4 tahun).
#   4. Besar langkah (rata-rata sesudah - sebelum) tertulis, dan uji sensitivitas
#      (tanpa DJF 2006/07 & 2007/08) dihitung dan disimpan ke CSV.
#   5. Perbandingan langkah vs tren linear (AIC) disimpan ke CSV.
#   6. DJF 2007/08 (La Nina kuat) diberi arsir abu-abu agar terlihat pengaruhnya.
#   7. Legenda dan keterangan statistik dipindah ke luar area data (tidak menutupi kurva).
#
# Jalankan:  py aji_fig9_v3.py
# Butuh: numpy, pandas, scipy, matplotlib, pymannkendall
# =====================================================
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy import stats
import pymannkendall as mk

# ---------------- 1. PATH ----------------
BASE = r"C:\Users\user\Documents\data_jurnal\newdata"
csv_path = os.path.join(BASE, "hasil_pca", "pc_scores_promax_v2.csv")
out_png = os.path.join(BASE, "Figure7_PC_timeseries_Pettitt_v3.png")
out_pdf = os.path.join(BASE, "Figure7_PC_timeseries_Pettitt_v3.pdf")
out_csv = os.path.join(BASE, "Figure7_statistik_v3.csv")
if not os.path.exists(csv_path):                       # agar skrip bisa dicoba di folder lain
    csv_path = "pc_scores_promax_v2.csv"
    out_png, out_pdf, out_csv = ("Figure7_v3.png", "Figure7_v3.pdf", "Figure7_statistik_v3.csv")

PCS = ["PC1", "PC2", "PC3", "PC4"]
ALPHA = 0.05
N_BOOT, BLOCK, SEED = 2000, 4, 42
LA_NINA_YEAR = 2008            # DJF 2007/08 (tahun Januari = 2008)

df = pd.read_csv(csv_path)
years = df["Year"].values.astype(int)
print(f"N musim = {len(df)} | {years.min()}-{years.max()}")


# ---------------- 2. Fungsi statistik ----------------
def pettitt(x):
    """Pettitt (1979). Mengembalikan (k, p): k = jumlah titik di rezim LAMA
    (jadi tahun terakhir rezim lama = years[k-1], tahun pertama rezim baru = years[k])."""
    x = np.asarray(x, float)
    n = len(x)
    r = stats.rankdata(x)
    U = np.array([2 * r[:t].sum() - t * (n + 1) for t in range(1, n)])
    k = int(np.argmax(np.abs(U)))
    K = abs(U[k])
    p = min(1.0, 2 * np.exp(-6 * K ** 2 / (n ** 3 + n ** 2)))
    return k + 1, p


def block_bootstrap_cp(x, yrs, n_boot=N_BOOT, block=BLOCK, seed=SEED):
    rng = np.random.default_rng(seed)
    n = len(x)
    out = []
    for _ in range(n_boot):
        idx = []
        while len(idx) < n:
            s = rng.integers(0, n - block + 1)
            idx.extend(range(s, s + block))
        k, _ = pettitt(x[idx[:n]])
        out.append(yrs[k])                      # tahun pertama rezim baru
    return np.percentile(out, [5, 95])


def sen_line(t, x):
    res = mk.original_test(x)
    slope = res.slope
    icpt = np.median(x - slope * t)
    return slope, icpt


def aic(resid, k):
    n = len(resid)
    return n * np.log(np.mean(resid ** 2)) + 2 * k


def analyse(x, yrs):
    t = np.arange(len(x))
    tf = mk.trend_free_pre_whitening_modification_test(x)
    sen, icpt = sen_line(t, x)
    k, p = pettitt(x)
    lo, hi = block_bootstrap_cp(x, yrs)
    # langkah vs tren linear
    lin = np.polyfit(t, x, 1)
    a_lin = aic(x - np.polyval(lin, t), 2)
    X = np.c_[np.ones(len(x)), (t >= k).astype(float)]
    b = np.linalg.lstsq(X, x, rcond=None)[0]
    a_step = aic(x - X @ b, 3)                  # 3 parameter: 2 level + lokasi titik ubah
    return dict(sen_per_dec=sen * 10, tfpw_p=tf.p, mk_trend=tf.trend,
                k=k, last_old=yrs[k - 1], first_new=yrs[k], pettitt_p=p,
                mean_before=x[:k].mean(), mean_after=x[k:].mean(),
                step=x[k:].mean() - x[:k].mean(), boot90_lo=lo, boot90_hi=hi,
                aic_linear=a_lin, aic_step=a_step, sen_icpt=icpt)


# ---------------- 3. Hitung ----------------
rows, R = [], {}
for pc in PCS:
    x = df[pc].values
    r = analyse(x, years)
    # sensitivitas
    for lab, keep in (("tanpa DJF 2006/07 & 2007/08", ~np.isin(years, [2007, 2008])),
                      ("1979-2025", years >= 1979)):
        k2, p2 = pettitt(x[keep])
        r[f"pettitt_p [{lab}]"] = p2
        r[f"first_new [{lab}]"] = years[keep][k2]
        r[f"tfpw_p [{lab}]"] = mk.trend_free_pre_whitening_modification_test(x[keep]).p
    R[pc] = r
    rows.append(dict(PC=pc, **r))
    print(f"{pc}: TFPW p={r['tfpw_p']:.3f} Sen={r['sen_per_dec']:+.2f}/dek | Pettitt p={r['pettitt_p']:.3f}, "
          f"rezim baru mulai {r['first_new']} (90% bootstrap {r['boot90_lo']:.0f}-{r['boot90_hi']:.0f}), "
          f"langkah={r['step']:+.2f} | AIC linear {r['aic_linear']:.1f} vs langkah {r['aic_step']:.1f}")
pd.DataFrame(rows).round(4).to_csv(out_csv, index=False)

# ---------------- 4. Plot ----------------
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 11, "axes.labelsize": 12,
    "axes.titlesize": 12, "xtick.labelsize": 11, "ytick.labelsize": 11,
    "axes.linewidth": 0.9, "savefig.dpi": 300,
})
C = dict(line="#1f77b4", trend="#2ca02c", cp="#d62728", b="#ff7f0e", a="#9467bd")

fig, axes = plt.subplots(2, 2, figsize=(12, 8.6), sharex=True, constrained_layout=True)
for ax, pc, lt in zip(axes.flat, PCS, "abcd"):
    x, r = df[pc].values, R[pc]
    t = np.arange(len(x))
    ax.axvspan(LA_NINA_YEAR - 0.5, LA_NINA_YEAR + 0.5, color="0.85", zorder=0)
    ax.plot(years, x, color=C["line"], lw=1.5, zorder=3)
    ax.axhline(0, color="k", lw=0.6, alpha=0.4)
    sig_trend = r["tfpw_p"] < ALPHA
    ax.plot(years, r["sen_icpt"] + (r["sen_per_dec"] / 10) * t, color=C["trend"],
            ls="-" if sig_trend else "--", lw=1.6, zorder=4)
    sig_cp = r["pettitt_p"] < ALPHA
    if sig_cp:
        xc = (r["last_old"] + r["first_new"]) / 2
        ax.axvspan(r["boot90_lo"] - 0.5, r["boot90_hi"] - 0.5, color=C["cp"], alpha=0.08, zorder=1)
        ax.axvline(xc, color=C["cp"], ls="--", lw=1.4, zorder=2)
        ax.hlines(r["mean_before"], years.min() - 1, xc, color=C["b"], ls=":", lw=1.8, zorder=2)
        ax.hlines(r["mean_after"], xc, years.max() + 1, color=C["a"], ls=":", lw=1.8, zorder=2)
    s1 = f"Sen {r['sen_per_dec']:+.2f}/decade, TFPW p = {r['tfpw_p']:.3f}" + ("" if sig_trend else " (n.s.)")
    s2 = (f"Pettitt p = {r['pettitt_p']:.3f}; new regime from DJF {r['first_new']-1}/{str(r['first_new'])[2:]}, "
          f"step {r['step']:+.2f}" if sig_cp else f"Pettitt p = {r['pettitt_p']:.2f} (n.s.)")
    ax.set_title(f"({lt}) {pc}", loc="left", fontweight="bold", pad=30)
    ax.text(0.0, 1.015, s1 + "\n" + s2, transform=ax.transAxes, fontsize=10, va="bottom", ha="left")
    ax.set_ylabel("PC score (standardized)")
    ax.grid(True, ls=":", alpha=0.5)
    ax.set_xlim(years.min() - 1, years.max() + 1)
for ax in axes[1]:
    ax.set_xlabel("Year (January of the DJF season)")

handles = [
    Line2D([0], [0], color=C["line"], lw=1.5, label="PC score"),
    Line2D([0], [0], color=C["trend"], lw=1.6, label="Sen slope (solid = TFPW p < 0.05)"),
    Line2D([0], [0], color=C["cp"], ls="--", lw=1.4, label="Pettitt change point (if p < 0.05)"),
    plt.Rectangle((0, 0), 1, 1, fc=C["cp"], alpha=0.12, label="90% block-bootstrap range of change point"),
    Line2D([0], [0], color=C["b"], ls=":", lw=1.8, label="Mean before"),
    Line2D([0], [0], color=C["a"], ls=":", lw=1.8, label="Mean after"),
    plt.Rectangle((0, 0), 1, 1, fc="0.85", label="DJF 2007/08 (strong La Niña)"),
]
fig.legend(handles=handles, loc="outside lower center", ncol=3, fontsize=10, frameon=False)
fig.suptitle("Promax PC scores of DJF precipitation over North Kalimantan, DJF 1955/56–2024/25 (n = 70)",
             fontsize=13, fontweight="bold")
fig.savefig(out_png, dpi=300, facecolor="white")
fig.savefig(out_pdf)
print("Saved:", out_png, out_pdf, out_csv)
