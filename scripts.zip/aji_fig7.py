# ============================================================
# FIGURE 6 - LOKAL (CMD / Windows) dengan GeoPandas
# Komposit anomali SLP (warna), Z700 (kontur), moisture flux (vektor)
#
# Install dulu (sekali saja) di cmd:
#   pip install numpy xarray netCDF4 scikit-learn factor_analyzer geopandas matplotlib
# ============================================================

import os
import warnings
import numpy as np
import xarray as xr
import matplotlib.pyplot as plt
import geopandas as gpd
from sklearn.decomposition import PCA
from factor_analyzer import Rotator

warnings.filterwarnings('ignore')

# ------------------------------------------------------------
# PATH  (sesuaikan DATA_DIR dengan lokasi file .nc kamu)
# ------------------------------------------------------------
DATA_DIR = r"C:\Users\user\Documents\data_jurnal\newdata"
SHP_DIR = r"C:\Users\user\Documents\data_jurnal\newdata\gadm41_IDN_shp"

# Level batas administrasi GADM: 0 = negara, 1 = provinsi, 2 = kabupaten/kota
GADM_LEVEL = 1
shp_path = os.path.join(SHP_DIR, f"gadm41_IDN_{GADM_LEVEL}.shp")

# ========== 0. Baca shapefile batas wilayah ==========
print("0. Membaca shapefile GADM...")
gdf = gpd.read_file(shp_path)
if gdf.crs is None:
    gdf = gdf.set_crs(epsg=4326)
else:
    gdf = gdf.to_crs(epsg=4326)

# ========== 1. Hitung PC scores dari curah hujan (DJF 1955-2025) ==========
print("1. Membaca data curah hujan dan menghitung PC scores...")
ds_pr = xr.open_dataset(os.path.join(DATA_DIR, "avgad.nc"))
# Subset Kalimantan Utara
lat_pr_min, lat_pr_max = 1.0, 4.5
lon_pr_min, lon_pr_max = 114.5, 118.0
lat_vals = ds_pr.latitude.values
if lat_vals[0] > lat_vals[-1]:
    ds_pr = ds_pr.sel(latitude=slice(lat_pr_max, lat_pr_min),
                      longitude=slice(lon_pr_min, lon_pr_max))
else:
    ds_pr = ds_pr.sel(latitude=slice(lat_pr_min, lat_pr_max),
                      longitude=slice(lon_pr_min, lon_pr_max))

time = ds_pr.valid_time
year = time.dt.year.values
month = time.dt.month.values
mask = (year >= 1955) & (year <= 2025) & ((month == 12) | (month == 1) | (month == 2))
tp_djf = ds_pr['tp'].isel(valid_time=mask) * 1000 * 30   # mm/bulan
years_djf = year[mask]
unique_years = np.unique(years_djf)
pr_annual = np.array([tp_djf.isel(valid_time=years_djf == yr).mean(dim='valid_time').values
                      for yr in unique_years])
X = pr_annual.reshape(len(unique_years), -1)
X_std = (X - X.mean(axis=0)) / X.std(axis=0)
X_std = np.nan_to_num(X_std)

n_pc = 4
pca = PCA(n_components=n_pc)
scores_unrot = pca.fit_transform(X_std)
loadings_unrot = pca.components_.T
rotator = Rotator(method='promax', power=2, normalize=True)
loadings_rot = rotator.fit_transform(loadings_unrot)
scores_rot = X_std @ loadings_rot @ np.linalg.inv(loadings_rot.T @ loadings_rot)
years_pr = unique_years
print(f"Explained variance: {pca.explained_variance_ratio_}")

# ========== 2. Baca data atmosfer (subset domain lebih luas) ==========
print("2. Membaca data atmosfer (mslworld.nc dan 3gb.nc)...")
ds_msl = xr.open_dataset(os.path.join(DATA_DIR, "mslworld.nc"))
msl = ds_msl['msl']
ds_pres = xr.open_dataset(os.path.join(DATA_DIR, "3gb.nc"))
z700 = ds_pres['z'].sel(pressure_level=700)
u850 = ds_pres['u'].sel(pressure_level=850)
v850 = ds_pres['v'].sel(pressure_level=850)
q850 = ds_pres['q'].sel(pressure_level=850)

# Domain atmosfer (5°S-15°N, 95°E-130°E)
lat_min_atm, lat_max_atm = -5, 15
lon_min_atm, lon_max_atm = 95, 130


def subset_domain(da):
    """Subset domain atmosfer, otomatis menyesuaikan urutan latitude."""
    if da.latitude.values[0] > da.latitude.values[-1]:
        lat_slice = slice(lat_max_atm, lat_min_atm)
    else:
        lat_slice = slice(lat_min_atm, lat_max_atm)
    return da.sel(latitude=lat_slice, longitude=slice(lon_min_atm, lon_max_atm))


msl = subset_domain(msl)
z700 = subset_domain(z700)
u850 = subset_domain(u850)
v850 = subset_domain(v850)
q850 = subset_domain(q850)


# Fungsi untuk menghitung rata-rata DJF per tahun
def annual_djf(data, time_dim='valid_time'):
    dt = data[time_dim].dt
    year = dt.year.values
    month = dt.month.values
    mask_djf = (month == 12) | (month == 1) | (month == 2)
    data_djf = data.isel({time_dim: mask_djf})
    years_djf = year[mask_djf]
    unique_years = np.unique(years_djf)
    unique_years = unique_years[(unique_years >= 1955) & (unique_years <= 2025)]
    annual = []
    for y in unique_years:
        idx = (years_djf == y)
        annual.append(data_djf.isel({time_dim: idx}).mean(dim=time_dim).values)
    return np.array(annual), unique_years


msl_ann, yrs_msl = annual_djf(msl)
z700_ann, yrs_z = annual_djf(z700)
u850_ann, yrs_u = annual_djf(u850)
v850_ann, yrs_v = annual_djf(v850)
q850_ann, yrs_q = annual_djf(q850)

# Sinkronkan tahun dengan PC scores
common = np.intersect1d(years_pr, yrs_msl)
common = np.intersect1d(common, yrs_z)
common = common[(common >= 1955) & (common <= 2025)]
print(f"Jumlah tahun sinkron: {len(common)}")
if len(common) == 0:
    raise ValueError("Tidak ada tahun yang sinkron. Periksa periode data.")

idx_pr = [np.where(years_pr == y)[0][0] for y in common]
idx_msl = [np.where(yrs_msl == y)[0][0] for y in common]
idx_z = [np.where(yrs_z == y)[0][0] for y in common]
idx_u = [np.where(yrs_u == y)[0][0] for y in common]
idx_v = [np.where(yrs_v == y)[0][0] for y in common]
idx_q = [np.where(yrs_q == y)[0][0] for y in common]

scores_common = scores_rot[idx_pr, :]
msl_common = msl_ann[idx_msl]
z700_common = z700_ann[idx_z]
u850_common = u850_ann[idx_u]
v850_common = v850_ann[idx_v]
q850_common = q850_ann[idx_q]

# Klimatologi
clim_msl = msl_common.mean(axis=0)
clim_z700 = z700_common.mean(axis=0)
clim_qu = (u850_common * q850_common).mean(axis=0)
clim_qv = (v850_common * q850_common).mean(axis=0)

# ========== 3. Komposit untuk setiap PC ==========
threshold = 1.5
years_arr = common
lon = msl.longitude.values
lat = msl.latitude.values

# Peta dasar GeoPandas (dipotong ke domain agar plotting ringan)
gdf_clip = gdf.cx[lon.min():lon.max(), lat.min():lat.max()]


def add_map_features(ax):
    """Pengganti ax.add_feature(cfeature...) dari cartopy."""
    gdf_clip.plot(ax=ax, facecolor='lightgray', edgecolor='none',
                  alpha=0.3, zorder=1)
    gdf_clip.boundary.plot(ax=ax, edgecolor='black', linewidth=0.6, zorder=5)
    ax.set_xlim(lon.min(), lon.max())
    ax.set_ylim(lat.min(), lat.max())
    ax.set_aspect('equal')
    ax.set_xlabel('Longitude (°E)')
    ax.set_ylabel('Latitude (°N)')


def composite(years_sel):
    """Hitung komposit anomali untuk daftar tahun terpilih."""
    if len(years_sel) == 0:
        nan = np.full_like(clim_msl, np.nan)
        return nan, nan.copy(), nan.copy(), nan.copy()
    idx = [np.where(years_arr == y)[0][0] for y in years_sel]
    a_msl = msl_common[idx].mean(axis=0) - clim_msl
    a_z = z700_common[idx].mean(axis=0) - clim_z700
    qu = (u850_common[idx] * q850_common[idx]).mean(axis=0)
    qv = (v850_common[idx] * q850_common[idx]).mean(axis=0)
    return a_msl, a_z, qu - clim_qu, qv - clim_qv


def plot_panel(ax, a_msl, a_z, a_qu, a_qv, title, step=2):
    # Warna SLP (anomali dalam hPa)
    cf = ax.pcolormesh(lon, lat, a_msl / 100, cmap='RdBu_r',
                       shading='auto', vmin=-3, vmax=3, zorder=2)
    plt.colorbar(cf, ax=ax, fraction=0.046, pad=0.04,
                 label='SLP anomaly (hPa)')
    # Kontur Z700
    if np.any(np.isfinite(a_z)):
        lev_pos = np.arange(0, np.nanmax(a_z) + 1, 1)
        lev_neg = np.arange(np.nanmin(a_z), 0, 1)
        if len(lev_pos) > 0:
            ax.contour(lon, lat, a_z, levels=lev_pos,
                       colors='black', linewidths=1.5, zorder=3)
        if len(lev_neg) > 0:
            ax.contour(lon, lat, a_z, levels=lev_neg,
                       colors='black', linewidths=1.5,
                       linestyles='dashed', zorder=3)
    # Vektor moisture flux
    ax.quiver(lon[::step], lat[::step],
              a_qu[::step, ::step], a_qv[::step, ::step],
              scale=50, width=0.003, color='black', zorder=4)
    add_map_features(ax)
    ax.set_title(title)


fig, axes = plt.subplots(n_pc, 2, figsize=(12, 4 * n_pc))

for pc in range(n_pc):
    sc = scores_common[:, pc]
    pos_years = years_arr[sc > threshold]
    neg_years = years_arr[sc < -threshold]
    print(f"PC{pc+1}: pos={len(pos_years)}, neg={len(neg_years)}")

    plot_panel(axes[pc, 0], *composite(pos_years),
               f'PC{pc+1} positive (n={len(pos_years)})')
    plot_panel(axes[pc, 1], *composite(neg_years),
               f'PC{pc+1} negative (n={len(neg_years)})')

plt.suptitle('Figure 6. Composite anomaly maps (DJF 1955-2025)')
plt.tight_layout()
out_file = os.path.join(DATA_DIR, "figure6_geopandas.png")
plt.savefig(out_file, dpi=300, bbox_inches='tight')
print(f"Gambar disimpan: {out_file}")
plt.show()