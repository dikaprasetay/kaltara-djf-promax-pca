"""
Tabel 2 (Kendall tau-b: skor PC vs indeks iklim) -- versi benar.

Jalankan (folder newdata):
  py tabel2_korelasi_v2.py --pc hasil_pca\\pc_scores_promax_v2.csv --idx indeks_iklim.csv --out hasil_tabel2

Isi:
  - Kendall tau-b, p-value biasa, dan p-value dengan koreksi autokorelasi (n efektif, Bretherton et al. 1999)
  - Koreksi uji berganda Benjamini-Hochberg (FDR 5%) atas seluruh 16 uji
  - Label tahun: kedua file harus berlabel tahun JANUARI (DJF y-1/y -> y)
"""
import argparse, os
import numpy as np
import pandas as pd
from scipy import stats

INDICES = ['DMI', 'Nino34', 'PDO', 'WPI']


def lag1(x):
    x = np.asarray(x, float) - np.mean(x)
    return float((x[:-1] * x[1:]).sum() / (x ** 2).sum())


def tau_test(x, y):
    n = len(x)
    tau, p_raw = stats.kendalltau(x, y)                       # tau-b, p asimtotik/eksak
    rho = lag1(x) * lag1(y)
    n_eff = n * (1 - rho) / (1 + rho) if rho > 0 else n        # tidak menaikkan n di atas n asli
    n_eff = min(n_eff, n)
    if n_eff > 4:
        sd = np.sqrt(2 * (2 * n_eff + 5) / (9 * n_eff * (n_eff - 1)))
        p_eff = 2 * (1 - stats.norm.cdf(abs(tau) / sd))
    else:
        p_eff = np.nan
    return tau, p_raw, p_eff, n_eff


def bh_fdr(p):
    p = np.asarray(p, float); m = len(p)
    order = np.argsort(p); ranked = p[order] * m / (np.arange(m) + 1)
    q = np.minimum.accumulate(ranked[::-1])[::-1]
    out = np.empty(m); out[order] = np.minimum(q, 1)
    return out


def build_table(pc, idx):
    pc = pc.copy(); idx = idx.copy()
    pc['Year'] = pc['Year'].astype(int); idx['Year'] = idx['Year'].astype(int)
    m = pd.merge(pc, idx, on='Year', how='inner')
    pcs = [c for c in pc.columns if c.upper().startswith('PC')]
    rows = []
    for ind in INDICES:
        for c in pcs:
            d = m[[ind, c]].dropna()
            tau, pr, pe, ne = tau_test(d[ind].values, d[c].values)
            rows.append(dict(Index=ind, PC=c, n=len(d), tau_b=tau, p_raw=pr, n_eff=ne, p_autocorr=pe))
    t = pd.DataFrame(rows)
    t['q_FDR_raw'] = bh_fdr(t['p_raw'].values)
    t['q_FDR_autocorr'] = bh_fdr(t['p_autocorr'].fillna(1).values)
    t['signif_FDR5%'] = t['q_FDR_autocorr'] < 0.05
    return m, t


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--pc', required=True)
    ap.add_argument('--idx', required=True)
    ap.add_argument('--out', default='hasil_tabel2')
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    m, t = build_table(pd.read_csv(a.pc), pd.read_csv(a.idx))
    print('Tahun dipakai: %d-%d (n=%d)' % (m['Year'].min(), m['Year'].max(), len(m)))
    show = t.copy()
    for c in ['tau_b']: show[c] = show[c].round(3)
    for c in ['p_raw', 'p_autocorr', 'q_FDR_raw', 'q_FDR_autocorr']: show[c] = show[c].round(4)
    show['n_eff'] = show['n_eff'].round(1)
    print(show.to_string(index=False))
    wide = t.pivot(index='Index', columns='PC', values='tau_b').loc[INDICES].round(3)
    print('\nTabel 2 (tau-b):'); print(wide.to_string())
    t.to_csv(os.path.join(a.out, 'Tabel2_detail.csv'), index=False)
    wide.to_csv(os.path.join(a.out, 'Tabel2_tau.csv'))
    print('\nSelesai. File di folder:', a.out)


if __name__ == '__main__':
    main()
