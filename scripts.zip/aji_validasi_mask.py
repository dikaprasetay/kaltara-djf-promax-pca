"""
Uji sensitivitas validasi ERA5 vs BMKG-ZOM terhadap definisi rata-rata spasial ERA5.

Skrip validasi lama (validasi_era5_bmkg_fig2.py) merata-ratakan ERA5 di seluruh kotak domain
(1.0-4.5N, 114.5-118.0E; 225 sel, bobot cos lat) -- kotak itu memuat laut dan wilayah luar provinsi.
Skrip ini menghitung ulang validasi dengan: (1) kotak domain (sama seperti sebelumnya),
(2) hanya sel yang titik tengahnya berada di dalam provinsi Kalimantan Utara (GADM).

Letakkan di folder yang sama dengan validasi_era5_bmkg_fig2.py, lalu:
  py aji_validasi_mask.py --era5 avgad.nc --bmkg Data_BMKG_Kaltara_DJF_1991_2024.xlsx
Hasil: tabel di layar + validasi_mask_sensitivitas.csv
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from validasi_era5_bmkg_fig2 import load_era5_tp, load_bmkg, to_mm_month, djf_series, validate  # noqa: E402


def masked_area_mean(x, lat, mask):
    """Rata-rata berbobot cos(lat) pada sel dengan mask True. x: (T, Y, X)."""
    w = np.cos(np.deg2rad(lat))[None, :, None] * mask[None, :, :].astype(float) * np.ones_like(x)
    ok = np.isfinite(x) & (w > 0)
    return np.where(ok, x * w, 0).sum((1, 2)) / np.where(ok, w, 0).sum((1, 2))


def province_mask(gadm_shp, lon, lat, name="kalimantanutara"):
    import geopandas as gpd
    g = gpd.read_file(gadm_shp)
    key = g["NAME_1"].str.lower().str.replace(" ", "", regex=False)
    geoms = g[key.str.contains(name)].geometry
    if geoms.empty:
        raise SystemExit(f"Provinsi '{name}' tidak ada di kolom NAME_1: {sorted(g['NAME_1'].unique())[:40]}")
    poly = geoms.union_all() if hasattr(geoms, "union_all") else geoms.unary_union
    LON, LAT = np.meshgrid(lon, lat)
    pts = gpd.GeoSeries(gpd.points_from_xy(LON.ravel(), LAT.ravel()))
    return pts.within(poly).values.reshape(LAT.shape)


def zom_mask(zom_shp, gadm_shp, lon, lat, out_csv, name="kalimantanutara"):
    """Mask dari poligon ZOM yang titik representatifnya berada di dalam provinsi.
    ZOM9120_INDONESIA.shp tidak punya atribut ID, jadi poligon dipilih berdasarkan lokasi.
    Seharusnya terpilih 7 poligon (KALTARA_1-7); jumlah lain berarti pemilihan perlu dicek."""
    import geopandas as gpd
    prov = gpd.read_file(gadm_shp)
    key = prov["NAME_1"].str.lower().str.replace(" ", "", regex=False)
    pg = prov[key.str.contains(name)].geometry
    pprov = pg.union_all() if hasattr(pg, "union_all") else pg.unary_union
    z = gpd.read_file(zom_shp)   # koordinat berupa derajat; CRS sengaja tidak dipakai/ditransformasi
    sel = z[z.geometry.representative_point().within(pprov)].copy()
    print(f"\nPoligon ZOM dengan titik representatif di dalam Kalimantan Utara: {len(sel)} (diharapkan 7)")
    if sel.empty:
        return None
    LON, LAT = np.meshgrid(lon, lat)
    pts = gpd.GeoSeries(gpd.points_from_xy(LON.ravel(), LAT.ravel()))
    cen = sel.geometry.representative_point()
    clat = cen.y.values
    # luas aproksimasi: derajat^2 -> km^2 (1 derajat lintang ~110.57 km, 1 derajat bujur ~111.32 km x cos(lintang))
    luas = sel.geometry.area.values * 110.57 * 111.32 * np.cos(np.deg2rad(clat))
    tab = pd.DataFrame({"indeks_poligon_di_shp": sel.index,
                        "luas_km2_aprox": np.round(luas, 0),
                        "pusat_lat": np.round(clat, 2),
                        "pusat_lon": np.round(cen.x.values, 2),
                        "n_sel_ERA5": [int(pts.within(g).sum()) for g in sel.geometry]})
    print(tab.to_string(index=False))
    tab.to_csv(out_csv, index=False, encoding="utf-8-sig")
    print("Tabel ZOM tersimpan:", os.path.abspath(out_csv))
    union = sel.geometry.union_all() if hasattr(sel.geometry, "union_all") else sel.geometry.unary_union
    return pts.within(union).values.reshape(LAT.shape)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--zomshp", default=os.path.join("zom_indonesia", "ZOM9120_INDONESIA.shp"))
    ap.add_argument("--zomtab", default="zom_kaltara_tabel.csv")
    ap.add_argument("--era5", default="avgad.nc")
    ap.add_argument("--bmkg", default="Data_BMKG_Kaltara_DJF_1991_2024.xlsx")
    ap.add_argument("--gadm", default=os.path.join("gadm41_IDN_shp", "gadm41_IDN_1.shp"))
    ap.add_argument("--out", default="validasi_mask_sensitivitas.csv")
    a = ap.parse_args()

    import xarray as xr
    lon = xr.open_dataset(a.era5)["longitude"].values
    t, tp, lat, _ = load_era5_tp(a.era5)
    mm = to_mm_month(t, tp)
    bmkg = load_bmkg(a.bmkg)

    masks = {"Kotak domain (semua sel)": np.ones((len(lat), len(lon)), bool),
             "Hanya sel di dalam provinsi (GADM)": province_mask(a.gadm, lon, lat)}
    if os.path.exists(a.zomshp):
        try:
            zm = zom_mask(a.zomshp, a.gadm, lon, lat, a.zomtab)
            if zm is not None and zm.any():
                masks["Sel di dalam poligon ZOM Kaltara"] = zm
        except Exception as e:  # blok ZOM tidak boleh menggagalkan hasil utama
            import traceback
            print("\nPERINGATAN: blok poligon ZOM dilewati ->", repr(e))
            traceback.print_exc()
    rows = []
    for name, m in masks.items():
        era5 = djf_series(t, masked_area_mean(mm, lat, m))
        _, res = validate(era5, bmkg)
        res = {"definisi_ERA5": name, "n_sel": int(m.sum()), **res}
        rows.append(res)
    df = pd.DataFrame(rows).set_index("definisi_ERA5")
    cols = ["n_sel", "n", "pearson_r", "r_ci95_low", "r_ci95_high", "slope", "slope_ci95",
            "bias_era5_minus_bmkg", "rmse", "rmse_pct_of_bmkg_mean", "mean_era5", "mean_bmkg"]
    print(df[cols].round(3).T.to_string())
    df[cols].round(4).to_csv(a.out, encoding="utf-8-sig")
    print("\nTersimpan:", os.path.abspath(a.out))


if __name__ == "__main__":
    main()