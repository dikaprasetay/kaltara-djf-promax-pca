"""
Peta korelasi spasial skor PC1-PC4 vs anomali hujan DJF -- pengganti aji_fig5.py.

Jalankan (folder newdata, setelah analisis_pca_promax_70musim.py):
  py fig_korelasi_v2.py --nc avgad.nc --scores hasil_pca\\pc_scores_promax_v2.csv --shp gadm41_IDN_shp\\gadm41_IDN_2.shp --out Fig_korelasi_v2

Perbaikan dibanding aji_fig5.py: skor Promax v2 (70 musim, bukan Varimax 71 musim), grid asli 0.25 derajat
(tanpa interpolasi 500x500), skala warna -1..1 yang tetap, titik = signifikan (FDR 5%), gaya bersama.
Catatan: skor PC diturunkan dari data yang sama, jadi peta ini menunjukkan di mana tiap mode "mewakili"
hujan; bukan bukti independen.
"""
import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from gaya_gambar import terapkan_gaya, CMAP, simpan
import analisis_pca_promax_70musim as A
from fig_komposit_v2 import bh_mask, read_boundary


def corr_maps(anom, scores):
    n = anom.shape[0]
    Z = (anom - anom.mean(0)) / anom.std(0, ddof=1)
    out = []
    for j in range(scores.shape[1]):
        s = (scores[:, j] - scores[:, j].mean()) / scores[:, j].std(ddof=1)
        r = np.tensordot(s, Z, axes=(0, 0)) / (n - 1)
        t = r * np.sqrt((n - 2) / np.clip(1 - r ** 2, 1e-12, None))
        p = 2 * stats.t.sf(np.abs(t), n - 2)
        out.append((r, bh_mask(p).reshape(r.shape)))
    return out


def make_figure(rain, lat, lon, years, scores_df, bnd, out):
    pcs = [c for c in scores_df.columns if c.upper().startswith('PC')]
    sc = scores_df.set_index('Year').loc[years, pcs].values
    res = corr_maps(rain - rain.mean(0), sc)
    terapkan_gaya()
    fig, axes = plt.subplots(2, 2, figsize=(11, 10.5), constrained_layout=True, sharex=True, sharey=True)
    LON, LAT = np.meshgrid(lon, lat)
    for j, (ax, (r, sig)) in enumerate(zip(axes.ravel(), res)):
        im = ax.pcolormesh(lon, lat, r, cmap=CMAP, vmin=-1, vmax=1, shading='nearest')
        ax.scatter(LON[sig], LAT[sig], s=7, c='k', marker='.', linewidths=0)
        if bnd is not None:
            bnd.boundary.plot(ax=ax, color='black', linewidth=0.9)
        ax.set_xlim(lon.min() - 0.125, lon.max() + 0.125); ax.set_ylim(min(lat) - 0.125, max(lat) + 0.125)
        ax.set_title(f'({"abcd"[j]}) {pcs[j]}', loc='left')
        ax.grid(True, ls=':', lw=0.5, alpha=0.6); ax.set_aspect('equal', adjustable='box')
        if j % 2 == 0: ax.set_ylabel('Latitude (°N)')
        if j >= 2: ax.set_xlabel('Longitude (°E)')
    cb = fig.colorbar(im, ax=axes, orientation='horizontal', fraction=0.04, pad=0.03, aspect=40)
    cb.set_label("Pearson correlation (r) between PC score and local DJF rainfall; dots: significant (FDR 5%)")
    simpan(fig, out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--nc', default='avgad.nc'); ap.add_argument('--scores', required=True)
    ap.add_argument('--shp', default=None); ap.add_argument('--out', default='Fig_korelasi_v2')
    a = ap.parse_args()
    import xarray as xr
    ds = xr.open_dataset(a.nc)
    t = pd.DatetimeIndex(pd.to_datetime(ds['valid_time'].values))
    rain, years = A.djf_array(t, A.to_mm_month(t, ds['tp'].values.astype('float64')))
    sc = pd.read_csv(a.scores); sc['Year'] = sc['Year'].astype(int)
    make_figure(rain, ds['latitude'].values, ds['longitude'].values, years, sc, read_boundary(a.shp), a.out)


if __name__ == '__main__':
    main()
