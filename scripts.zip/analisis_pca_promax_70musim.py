"""
PCA + Promax untuk curah hujan DJF Kaltara (ERA5) -- versi satu skrip, 70 musim lengkap.

Jalankan (env_sst, folder newdata):
  py analisis_pca_promax_70musim.py --era5 avgad.nc --bmkg Data_BMKG_Kaltara_DJF_1991_2024.xlsx --out hasil_pca

Perbedaan penting dari skrip lama (aji_tabel1.py):
  1. Hanya musim DJF LENGKAP (Des, Jan, Feb) -> 70 musim, DJF 1955/56 ... 2024/25.
  2. Satuan mm/bulan memakai jumlah hari asli tiap bulan (bukan 30).
  3. Promax dikenakan pada loading BERSKALA (eigenvektor x akar eigenvalue), cara baku (Richman 1986).
  4. Matriks korelasi antar-faktor (Phi) dilaporkan, plus varians pola vs struktur.
  5. Tanda tiap PC dikunci: skor positif = hujan rata-rata domain lebih tinggi (korelasi positif). Ini mengakhiri
     kebingungan tanda PC1 vs Nino 3.4.
  6. Aturan North (selisih eigenvalue) dicetak untuk menjawab 'kenapa 4 PC'.
Semua skor dan tabel keluar dari satu analisis ini.
"""
import argparse, os
import numpy as np
import pandas as pd
from scipy import stats


# ---------------- rotasi ----------------
def varimax(A, gamma=1.0, q=1000, tol=1e-9):
    p, k = A.shape
    h = np.sqrt((A ** 2).sum(1)); h[h == 0] = 1.0       # normalisasi Kaiser
    An = A / h[:, None]
    R = np.eye(k); d = 0.0
    for _ in range(q):
        L = An @ R
        u, s, vh = np.linalg.svd(An.T @ (L ** 3 - (gamma / p) * L @ np.diag((L ** 2).sum(0))))
        R = u @ vh
        d_old, d = d, s.sum()
        if d_old != 0 and d / d_old < 1 + tol:
            break
    return A @ R, R


def promax(Av, power=3):
    Q = Av * np.abs(Av) ** (power - 1)
    U = np.linalg.lstsq(Av, Q, rcond=None)[0]
    d = np.diag(np.linalg.inv(U.T @ U))
    U = U * np.sqrt(d)
    Ap = Av @ U
    Phi = np.linalg.inv(U.T @ U)                          # korelasi antar-faktor
    return Ap, U, Phi


# ---------------- data ----------------
def to_mm_month(t, tp_m_per_day):
    return tp_m_per_day * 1000.0 * np.asarray(t.days_in_month, float)[:, None, None]


def djf_array(t, mm):
    """(musim, lat, lon) hanya untuk DJF lengkap; kembalikan juga label tahun Januari (DJF y-1/y -> y)."""
    idx = {(int(y), int(m)): i for i, (y, m) in enumerate(zip(t.year, t.month))}
    seasons, years = [], []
    for y in sorted({int(y) for y in t.year}):
        k = [(y, 12), (y + 1, 1), (y + 1, 2)]
        if all(x in idx for x in k):
            seasons.append(np.mean([mm[idx[x]] for x in k], axis=0)); years.append(y + 1)
    return np.array(seasons), np.array(years)


def area_mean(x, lat):
    w = np.cos(np.deg2rad(lat))[None, :, None] * np.ones_like(x)
    return (x * w).sum((1, 2)) / w.sum((1, 2))


# ---------------- analisis inti ----------------
def analyze(rain, lat, years, k=4, power=3, base=(1982, 2010)):
    n, nlat, nlon = rain.shape
    b = (years >= base[0]) & (years <= base[1])
    z = (rain - rain[b].mean(0)) / rain[b].std(0, ddof=1)            # z-score baseline
    X = z.reshape(n, -1); X = X - X.mean(0)
    p = X.shape[1]
    U_, S, Vt = np.linalg.svd(X, full_matrices=False)
    lam = S ** 2 / (n - 1)                                            # eigenvalue (var total = p)
    var_unrot = 100 * lam / lam.sum()
    err = lam * np.sqrt(2.0 / n)                                      # North et al. (1982)
    north = [bool(lam[i] - err[i] > lam[i + 1] + err[i + 1]) for i in range(min(8, len(lam) - 1))]
    A = Vt[:k].T * np.sqrt(lam[:k])                                   # loading berskala (p x k)
    F = (X @ Vt[:k].T) / np.sqrt(lam[:k])                             # skor unit-varian (n x k)
    Av, R = varimax(A)
    Ap, U, Phi = promax(Av, power)
    Fp = (F @ R) @ np.linalg.inv(U).T                                 # skor oblique
    S_struct = Ap @ Phi                                               # matriks struktur
    # kunci tanda: skor positif = rata-rata hujan domain lebih tinggi (korelasi positif dengan hujan domain)
    dom = area_mean(rain - rain.mean(0), lat)
    sign = np.where([stats.pearsonr(Fp[:, j], dom)[0] >= 0 for j in range(k)], 1.0, -1.0)
    Ap, Fp, S_struct = Ap * sign, Fp * sign, S_struct * sign
    Phi = Phi * np.outer(sign, sign)
    res = dict(
        n=n, p=p, tot_var=lam.sum(), years=years, lam=lam, var_unrot=var_unrot, north_separated=north,
        var_pattern=100 * (Ap ** 2).sum(0) / lam.sum(), var_struct=100 * (S_struct ** 2).sum(0) / lam.sum(),  # penyebut sama dgn var_unrot
        total_k=var_unrot[:k].sum(), Phi=Phi, scores=Fp, loadings=Ap, dom_rain=dom,
        r_dom=[stats.pearsonr(Fp[:, j], dom)[0] for j in range(k)],
        nlat=nlat, nlon=nlon)
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--era5', required=True)
    ap.add_argument('--bmkg')
    ap.add_argument('--out', default='hasil_pca')
    ap.add_argument('--k', type=int, default=4)
    ap.add_argument('--power', type=float, default=3)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    import xarray as xr
    ds = xr.open_dataset(a.era5)
    t = pd.DatetimeIndex(pd.to_datetime(ds['valid_time'].values))
    lat = ds['latitude'].values
    mm = to_mm_month(t, ds['tp'].values.astype('float64'))
    rain, years = djf_array(t, mm)
    print('Musim DJF lengkap:', len(years), '| DJF %d/%02d sampai DJF %d/%02d' % (years[0] - 1, years[0] % 100, years[-1] - 1, years[-1] % 100))

    r = analyze(rain, lat, years, a.k, a.power)
    print('Total varians (jumlah eigenvalue) = %.2f ; jumlah sel p = %d' % (r['tot_var'], r['p']))
    print('\n== EIGENVALUE & ATURAN NORTH ==')
    for i in range(min(8, len(r['lam']))):
        print('PC%d  varians=%.2f%%  terpisah dari PC%d? %s' % (i + 1, r['var_unrot'][i], i + 2,
              r['north_separated'][i] if i < len(r['north_separated']) else '-'))
    print('\n== VARIANS (k=%d, Promax power=%g) ==' % (a.k, a.power))
    print('Total k mode (sama sebelum/sesudah rotasi): %.2f%%' % r['total_k'])
    print('%-5s %10s %14s %14s' % ('PC', 'Unrotated', 'Pola(unik)', 'Struktur'))
    for j in range(a.k):
        print('PC%-3d %9.2f%% %13.2f%% %13.2f%%' % (j + 1, r['var_unrot'][j], r['var_pattern'][j], r['var_struct'][j]))
    print('\n== KORELASI ANTAR-FAKTOR (Phi) ==')
    print(pd.DataFrame(r['Phi'], index=['PC%d' % (i + 1) for i in range(a.k)], columns=['PC%d' % (i + 1) for i in range(a.k)]).round(3).to_string())
    print('\nKorelasi skor dengan rata-rata hujan domain ERA5 (positif = skor tinggi = basah):',
          [round(x, 3) for x in r['r_dom']])
    sc = pd.DataFrame(r['scores'], columns=['PC%d' % (i + 1) for i in range(a.k)])
    sc['Year'] = r['years']                                   # label = tahun Januari (DJF y-1/y)
    if a.bmkg:
        bm = pd.read_excel(a.bmkg); bm.columns = ['d', 'p']; bm['Year'] = bm['d'].astype(str).str[:4].astype(int) + 1
        m = sc.merge(bm, on='Year')
        print('Korelasi skor dengan BMKG (n=%d):' % len(m), [round(stats.pearsonr(m['PC%d' % (i + 1)], m['p'])[0], 3) for i in range(a.k)])
    sc.to_csv(os.path.join(a.out, 'pc_scores_promax_v2.csv'), index=False)
    pd.DataFrame(r['Phi']).to_csv(os.path.join(a.out, 'factor_correlation.csv'), index=False)
    lo = pd.DataFrame(r['loadings'], columns=['PC%d' % (i + 1) for i in range(a.k)])
    lo.to_csv(os.path.join(a.out, 'loadings_promax_v2.csv'), index=False)
    print('\nSelesai. File ada di folder:', a.out)


if __name__ == '__main__':
    main()
