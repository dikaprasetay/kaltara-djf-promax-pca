# =====================================================
# FIGURE 9 (v3) - TREN SST DJF (ERA5 SST, sstworld.nc)
#
# Perubahan dibanding versi sebelumnya (Reviewer 3, Minor 20; Reviewer 1, butir 1.17):
#   1. LABEL DATA DIPERBAIKI: sstworld.nc adalah SST ERA5 (0,25 derajat, 30S-30N, 30-280E),
#      BUKAN ERSSTv5 (2 derajat). Judul lama "ERSSTv5" salah. Ubah SST_LABEL bila nanti memakai
#      ERSSTv5 yang sebenarnya.
#   2. Uji signifikansi memperhitungkan autokorelasi lag-1 (n efektif, Santer et al. 2000) dan
#      koreksi uji berganda Benjamini-Hochberg (FDR 5%). Sebelumnya p OLS mentah di tiap grid.
#   3. Tidak ada lagi subsampling titik (step=2) yang menyesatkan; yang diarsir adalah SEMUA
#      sel yang TIDAK signifikan (ubah STIPPLE_SIGNIFICANT = True untuk membalik).
#   4. Ada kotak Laut Sulawesi; rata-rata area dan trennya (lereng Sen, TFPW-MK, OLS dengan
#      selang 95%) dihitung untuk 1941-2024 dan 1979-2024 dan disimpan ke CSV -> dasar klaim
#      "pemanasan Laut Sulawesi" di Diskusi.
#   5. Cek jumlah bulan per musim (harus 3) sehingga musim tidak lengkap tidak ikut.
#   6. Tata letak: skala warna horizontal, tidak ada ruang putih besar di atas dan bawah peta.
#
# Jalankan:  py aji_fig11_v3.py
# Butuh: numpy, pandas, xarray, geopandas, matplotlib, scipy, pymannkendall
# =====================================================
import os
import warnings
import numpy as np
import pandas as pd
import xarray as xr
import geopandas as gpd
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from matplotlib.patches import Rectangle
from scipy import stats
import pymannkendall as mk

warnings.filterwarnings("ignore")

BASE = r"C:\Users\user\Documents\data_jurnal\newdata"
file_path = os.path.join(BASE, "sstworld.nc")
shp_main = os.path.join(BASE, "gadm41_IDN_shp", "gadm41_IDN_0.shp")
out_png = os.path.join(BASE, "Figure9_SST_Trend_DJF_v3.png")
out_pdf = os.path.join(BASE, "Figure9_SST_Trend_DJF_v3.pdf")
out_csv = os.path.join(BASE, "Figure9_Sulawesi_Sea_trend_v3.csv")
if not os.path.exists(file_path):                           # untuk uji di folder lain
    file_path, shp_main = "sstworld.nc", "idn0_test.shp"
    out_png, out_pdf, out_csv = "Figure9_v3.png", "Figure9_v3.pdf", "Figure9_Sulawesi_v3.csv"

SST_LABEL = "ERA5 SST"                       # <- BUKAN "ERSSTv5" (lihat catatan di atas)
YEARS = (1941, 2024)                         # tahun JANUARI musim DJF (Des tahun sebelumnya)
SULAWESI_BOX = (117.5, 123.0, 1.0, 5.0)      # lon0, lon1, lat0, lat1 -- ASUMSI, sesuaikan dengan Metode
STIPPLE_SIGNIFICANT = False                  # False: arsir sel TIDAK signifikan; True: titik di sel signifikan
ALPHA = 0.05
XMIN, XMAX, YMIN, YMAX = 30, 280, -30, 30


# ---------------- DJF ----------------
ds = xr.open_dataset(file_path)
if "valid_time" in ds.coords:
    ds = ds.rename({"valid_time": "time"})
t = pd.DatetimeIndex(ds["time"].values)
mon = t.month
wy = np.where(mon == 12, t.year + 1, t.year)                 # Des digabung ke tahun berikutnya
isdjf = np.isin(mon, [12, 1, 2])
sst = ds["sst"].isel(time=np.where(isdjf)[0]) - 273.15       # pilih DJF dulu (hemat memori), baru K -> degC
wy = wy[isdjf]
sst = sst.assign_coords(wy=("time", wy))
n_per = pd.Series(wy).value_counts()                         # hitung bulan dari AXIS WAKTU (bukan dari data,
full = [int(y) for y in n_per.index if n_per[y] == 3]        # karena sel pojok bisa daratan/NaN)
djf = sst.groupby("wy").mean("time").sel(wy=[y for y in full if YEARS[0] <= y <= YEARS[1]])
yrs = djf["wy"].values.astype(int)
print(f"Musim DJF: {len(yrs)} ({yrs.min()}-{yrs.max()})  [DJF {yrs.min()-1}/{str(yrs.min())[2:]} - {yrs.max()-1}/{str(yrs.max())[2:]}]")
lat, lon = djf["latitude"].values, djf["longitude"].values
Y = djf.values.astype("float64")                             # (n, lat, lon)
n = Y.shape[0]


# ---------------- tren vektor + p dengan n efektif ----------------
def bh_fdr_mask(p, alpha=ALPHA):
    ok = np.isfinite(p)
    out = np.zeros(p.shape, bool)
    pv = p[ok]
    order = np.argsort(pv)
    thr = alpha * (np.arange(1, pv.size + 1) / pv.size)
    below = pv[order] <= thr
    sig = np.zeros(pv.size, bool)
    if below.any():
        sig[order[: np.where(below)[0].max() + 1]] = True
    out[ok] = sig
    return out


valid = np.isfinite(Y).all(axis=0) & (Y.std(axis=0) > 0)
Z = Y[:, valid]
x = np.arange(n, dtype=float)
xc = x - x.mean()
sxx = (xc ** 2).sum()
slope = (xc[:, None] * (Z - Z.mean(0))).sum(0) / sxx             # degC per tahun
resid = (Z - Z.mean(0)) - slope * xc[:, None]
r1 = (resid[:-1] * resid[1:]).sum(0) / (resid ** 2).sum(0)
n_eff = np.clip(n * (1 - r1) / (1 + r1), 4.0, n)                 # tidak dinaikkan di atas n
s2 = (resid ** 2).sum(0) / (n - 2)
se = np.sqrt(s2 / sxx) * np.sqrt((n - 2) / (n_eff - 2))
tval = slope / se
pval = 2 * stats.t.sf(np.abs(tval), n_eff - 2)

slope_map = np.full(valid.shape, np.nan)
p_map = np.full(valid.shape, np.nan)
slope_map[valid] = slope * 10.0                                  # degC per dekade
p_map[valid] = pval
sig_map = bh_fdr_mask(p_map)
print(f"Sel laut: {int(valid.sum())} | signifikan p<0.05 mentah: {int((p_map < ALPHA).sum())} | "
      f"signifikan FDR 5%: {int(sig_map.sum())}")


# ---------------- Laut Sulawesi: rata-rata area ----------------
def box_series(djf_da, box):
    lo0, lo1, la0, la1 = box
    sub = djf_da.sel(longitude=slice(lo0, lo1), latitude=slice(la1, la0) if lat[0] > lat[-1] else slice(la0, la1))
    w = np.cos(np.deg2rad(sub["latitude"]))
    ok = np.isfinite(sub).all("wy")
    sub = sub.where(ok)
    return (sub * w).sum(("latitude", "longitude")) / (w * ok).sum(("latitude", "longitude")), int(ok.sum())


ser_all, ncell = box_series(djf, SULAWESI_BOX)
rows = []
for (a, b) in ((YEARS[0], YEARS[1]), (1979, YEARS[1])):
    s = ser_all.sel(wy=slice(a, b)).values
    tt = np.arange(len(s))
    tf = mk.trend_free_pre_whitening_modification_test(s)
    lr = stats.linregress(tt, s)
    res = s - (lr.intercept + lr.slope * tt)
    rho = (res[:-1] * res[1:]).sum() / (res ** 2).sum()
    ne = min(len(s), max(4.0, len(s) * (1 - rho) / (1 + rho)))
    ci = stats.t.ppf(0.975, ne - 2) * lr.stderr * np.sqrt((len(s) - 2) / (ne - 2))
    rows.append(dict(box=str(SULAWESI_BOX), sea_cells=ncell, period=f"DJF {a-1}/{str(a)[2:]}-{b-1}/{str(b)[2:]}",
                     n=len(s), sen_degC_per_decade=tf.slope * 10, tfpw_p=tf.p,
                     ols_degC_per_decade=lr.slope * 10, ols_ci95=ci * 10, lag1_resid=rho))
    print(rows[-1])
pd.DataFrame(rows).round(4).to_csv(out_csv, index=False)

# deret DJF rata-rata kotak (tahun = Januari musim DJF) + asosiasi dengan skor PC (bila tersedia)
ser_df = pd.DataFrame({"Year": ser_all["wy"].values.astype(int), "SST_box_degC": ser_all.values})
ser_df.to_csv(out_csv.replace(".csv", "_series.csv"), index=False)
pc_csv = os.path.join(BASE, "hasil_pca", "pc_scores_promax_v2.csv")
if not os.path.exists(pc_csv):
    pc_csv = "pc_scores_promax_v2.csv"
if os.path.exists(pc_csv):
    m = pd.read_csv(pc_csv).merge(ser_df, on="Year")
    tt = np.arange(len(m))
    def detr(v):
        sl = mk.original_test(v).slope
        return v - sl * tt
    arows = []
    for pc in ["PC1", "PC2", "PC3", "PC4"]:
        tau_r, p_r = stats.kendalltau(m[pc], m["SST_box_degC"])
        tau_d, p_d = stats.kendalltau(detr(m[pc].values), detr(m["SST_box_degC"].values))
        arows.append(dict(PC=pc, n=len(m), tau_raw=tau_r, p_raw=p_r, tau_detrended=tau_d, p_detrended=p_d))
    A = pd.DataFrame(arows).round(4)
    print("Asosiasi skor PC vs SST kotak Laut Sulawesi (Kendall tau-b; detrended = tren Sen dibuang dari keduanya):")
    print(A.to_string(index=False))
    A.to_csv(out_csv.replace(".csv", "_asosiasi_PC.csv"), index=False)

# ---------------- gambar ----------------
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 12, "axes.titlesize": 13,
                     "axes.labelsize": 12, "hatch.linewidth": 0.3})
gdf = gpd.read_file(shp_main).to_crs(epsg=4326)
fig, ax = plt.subplots(figsize=(14, 4.4), constrained_layout=True)
vmax = 0.25
norm = TwoSlopeNorm(vmin=-vmax, vcenter=0, vmax=vmax)
im = ax.pcolormesh(lon, lat, slope_map, cmap="RdBu_r", norm=norm, shading="nearest")
mask = sig_map if STIPPLE_SIGNIFICANT else (np.isfinite(slope_map) & ~sig_map)
ax.contourf(lon, lat, mask.astype(float), levels=[0.5, 1.5], colors="none", hatches=["////" if not STIPPLE_SIGNIFICANT else "...."])
gdf.cx[XMIN:XMAX, YMIN:YMAX].boundary.plot(ax=ax, edgecolor="k", linewidth=0.4)
lo0, lo1, la0, la1 = SULAWESI_BOX
ax.add_patch(Rectangle((lo0, la0), lo1 - lo0, la1 - la0, fill=False, ec="k", lw=1.6, ls="--"))
ax.text((lo0 + lo1) / 2, la1 + 1.5, "Sulawesi Sea box", fontsize=11, ha="center", va="bottom")
ax.set_xlim(XMIN, XMAX); ax.set_ylim(YMIN, YMAX); ax.set_aspect("equal", adjustable="box")
ax.set_xlabel("Longitude (°E)"); ax.set_ylabel("Latitude (°N)")
ax.grid(True, ls=":", alpha=0.4)
hat = "dots = significant" if STIPPLE_SIGNIFICANT else "hatching = not significant"
ax.set_title(f"Linear trend of DJF sea-surface temperature ({SST_LABEL}), "
             f"DJF {YEARS[0]-1}/{str(YEARS[0])[2:]}–{YEARS[1]-1}/{str(YEARS[1])[2:]}", fontsize=13, fontweight="bold")
cb = fig.colorbar(im, ax=ax, orientation="horizontal", fraction=0.05, pad=0.06, aspect=60)
cb.set_label(f"SST trend (°C per decade); {hat} (lag-1-adjusted t-test, FDR 5%)")
fig.savefig(out_png, dpi=300, facecolor="white")
fig.savefig(out_pdf)
print("Saved:", out_png, out_pdf, out_csv)
