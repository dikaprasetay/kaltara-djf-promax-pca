"""
Sensitivitas PCA-Promax untuk jawaban Reviewer 4 (4.3) dan Reviewer 3.
Letakkan di folder yang sama dengan analisis_pca_promax_70musim.py.

Jalankan (folder newdata):
  py sensitivitas_pca.py --era5 avgad.nc --out hasil_pca

Keluaran (folder --out):
  sens_north.csv        eigenvalue, galat North, terpisah atau tidak
  sens_k.csv            k = 3,4,5,6 vs solusi dasar (k=4, kappa=3)
  sens_kappa.csv        kappa = 2,3,4,5 vs solusi dasar
  sens_varimax.csv      Varimax (ortogonal) vs Promax dasar
  sens_varians_total.csv  total varians k mode (menjawab 88,84 vs 88,72)
Ukuran kemiripan: |Tucker congruence| pola loading; |r| skor (dipasangkan otomatis).
"""
import argparse, os
import numpy as np
import pandas as pd
import analisis_pca_promax_70musim as P


def congruence(a, b):
    return float(abs(a @ b) / np.sqrt((a @ a) * (b @ b)))


def match(base, other, base_sc, other_sc):
    """Pasangkan tiap PC dasar dengan PC lain yang loading-nya paling mirip."""
    rows = []
    for j in range(base.shape[1]):
        cs = [congruence(base[:, j], other[:, i]) for i in range(other.shape[1])]
        i = int(np.argmax(cs))
        r = abs(np.corrcoef(base_sc[:, j], other_sc[:, i])[0, 1])
        rows.append((j + 1, i + 1, cs[i], r))
    return rows


def varimax_solution(rain, lat, years, k=4, base=(1982, 2010)):
    """Varimax murni (ortogonal) dengan data dan baseline yang sama."""
    n = rain.shape[0]
    b = (years >= base[0]) & (years <= base[1])
    z = (rain - rain[b].mean(0)) / rain[b].std(0, ddof=1)
    X = z.reshape(n, -1); X = X - X.mean(0)
    U_, S, Vt = np.linalg.svd(X, full_matrices=False)
    lam = S ** 2 / (n - 1)
    A = Vt[:k].T * np.sqrt(lam[:k]); F = (X @ Vt[:k].T) / np.sqrt(lam[:k])
    Av, R = P.varimax(A)
    Fv = F @ R
    dom = P.area_mean(rain - rain.mean(0), lat)
    sg = np.where([np.corrcoef(Fv[:, j], dom)[0, 1] >= 0 for j in range(k)], 1.0, -1.0)
    return Av * sg, Fv * sg, 100 * (Av ** 2).sum(0) / lam.sum()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--era5', required=True)
    ap.add_argument('--out', default='hasil_pca')
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    import xarray as xr
    ds = xr.open_dataset(a.era5)
    t = pd.DatetimeIndex(pd.to_datetime(ds['valid_time'].values))
    lat = ds['latitude'].values
    rain, years = P.djf_array(t, P.to_mm_month(t, ds['tp'].values.astype('float64')))
    print('Musim:', len(years))

    base = P.analyze(rain, lat, years, 4, 3)
    # 1. North
    lam = base['lam']; err = lam * np.sqrt(2.0 / base['n'])
    rows = []
    for i in range(8):
        rows.append(dict(PC=i + 1, eigenvalue=lam[i], var_pct=base['var_unrot'][i], north_err=err[i],
                         cum_var_pct=base['var_unrot'][:i + 1].sum(),
                         separated_from_next=bool(lam[i] - err[i] > lam[i + 1] + err[i + 1])))
    d = pd.DataFrame(rows).round(3); d.to_csv(os.path.join(a.out, 'sens_north.csv'), index=False)
    print('\n== NORTH ==\n', d.to_string(index=False))

    # 2. total varians
    pd.DataFrame([dict(total_k_unrotated=base['total_k'],
                       sum_pattern=base['var_pattern'].sum(), sum_structure=base['var_struct'].sum(),
                       note='pola menjumlah ke total hanya jika faktor tak berkorelasi; struktur melebihi total')]
                 ).round(2).to_csv(os.path.join(a.out, 'sens_varians_total.csv'), index=False)
    print('\nTotal varians k=4 (unrotated): %.2f%% | sum pola %.2f%% | sum struktur %.2f%%'
          % (base['total_k'], base['var_pattern'].sum(), base['var_struct'].sum()))

    # 3. k
    rows = []
    for k in (3, 4, 5, 6):
        r = P.analyze(rain, lat, years, k, 3)
        for jb, jo, c, rr in match(base['loadings'], r['loadings'], base['scores'], r['scores']):
            rows.append(dict(k=k, PC_dasar=jb, PC_cocok=jo, tucker=c, abs_r_skor=rr,
                             total_var_k=r['total_k'], max_Phi=np.abs(r['Phi'][np.triu_indices(k, 1)]).max()))
    d = pd.DataFrame(rows).round(3); d.to_csv(os.path.join(a.out, 'sens_k.csv'), index=False)
    print('\n== SENSITIVITAS k ==\n', d.to_string(index=False))

    # 4. kappa
    rows = []
    for kp in (2, 3, 4, 5):
        r = P.analyze(rain, lat, years, 4, kp)
        for jb, jo, c, rr in match(base['loadings'], r['loadings'], base['scores'], r['scores']):
            rows.append(dict(kappa=kp, PC_dasar=jb, PC_cocok=jo, tucker=c, abs_r_skor=rr,
                             max_Phi=np.abs(r['Phi'][np.triu_indices(4, 1)]).max()))
    d = pd.DataFrame(rows).round(3); d.to_csv(os.path.join(a.out, 'sens_kappa.csv'), index=False)
    print('\n== SENSITIVITAS kappa ==\n', d.to_string(index=False))

    # 5. Varimax
    Av, Fv, vv = varimax_solution(rain, lat, years)
    rows = []
    for jb, jo, c, rr in match(base['loadings'], Av, base['scores'], Fv):
        rows.append(dict(PC_promax=jb, PC_varimax=jo, tucker=c, abs_r_skor=rr, var_varimax_pct=vv[jo - 1]))
    d = pd.DataFrame(rows).round(3); d.to_csv(os.path.join(a.out, 'sens_varimax.csv'), index=False)
    print('\n== VARIMAX vs PROMAX ==\n', d.to_string(index=False))
    pd.DataFrame(Fv, columns=['V%d' % (i + 1) for i in range(4)]).assign(Year=years).round(4)\
      .to_csv(os.path.join(a.out, 'pc_scores_varimax.csv'), index=False)
    print('\nSelesai. File di:', a.out)


if __name__ == '__main__':
    main()
