"""
Figure 3 (v3): pola loading Promax (kappa = 3) PC1-PC4, DJF 1955/56-2024/25 (n = 70).

Digambar LANGSUNG dari hasil analisis (hasil_pca/loadings_promax_v2.csv), tanpa menghitung ulang PCA,
sehingga tanda (positif = lebih basah) sama dengan skor PC, Tabel 1-4 dan komposit Figure 4.
CSV: 225 baris = 15 x 15 sel; baris disusun menurut lintang MENURUN (4.5 -> 1.0 N), lalu bujur menaik
(114.5 -> 118.0 E); kolom PC1..PC4 (urutan ini sudah diverifikasi terhadap pola PC1/PC3 di naskah).

Jalankan dari folder newdata:   py aji_fig3_v3.py
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, MultipleLocator

CSV = os.path.join("hasil_pca", "loadings_promax_v2.csv")
GADM_DIR = "gadm41_IDN_shp"
OUT_PREFIX = "Figure3_loading_patterns_v3"
LAT = np.arange(4.5, 1.0 - 1e-9, -0.25)    # menurun, sesuai urutan baris CSV
LON = np.arange(114.5, 118.0 + 1e-9, 0.25)
VMAX = 1.0                                  # skala simetris, sama untuk keempat panel

d = pd.read_csv(CSV)
assert len(d) == LAT.size * LON.size and list(d.columns[:4]) == ["PC1", "PC2", "PC3", "PC4"], d.columns.tolist()
fields = {pc: d[pc].values.reshape(LAT.size, LON.size) for pc in ("PC1", "PC2", "PC3", "PC4")}

# pemeriksaan tanda terhadap teks Section 3.2: PC4 positif di jalur barat, negatif di tepi timur
lo, la = np.meshgrid(LON, LAT)
west = fields["PC4"][(lo >= 115.25) & (lo <= 115.75)].mean()
east = fields["PC4"][(lo >= 117.5) & (la >= 2.0) & (la <= 3.5)].mean()
print(f"PC4: barat {west:+.2f}, timur {east:+.2f}")
assert west > 0 > east, "Tanda PC4 tidak sesuai teks naskah, jangan lanjutkan."

gadm = None
try:
    import geopandas as gpd
    from shapely.geometry import box
    p = os.path.join(GADM_DIR, "gadm41_IDN_1.shp")
    if os.path.exists(p):
        g = gpd.read_file(p).to_crs("EPSG:4326")
        gadm = gpd.clip(g, box(114.5, 1.0, 118.0, 4.5))
except ImportError:
    print("geopandas tidak terpasang -> batas provinsi dilewati")

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "pdf.fonttype": 42})
fig, axes = plt.subplots(2, 2, figsize=(8.6, 8.4), sharex=True, sharey=True)
dx = dy = 0.125
for ax, (pc, tag) in zip(axes.ravel(), zip(fields, "abcd")):
    im = ax.pcolormesh(LON, LAT, fields[pc], cmap="RdBu_r", vmin=-VMAX, vmax=VMAX,
                       shading="auto", rasterized=True, zorder=1)
    if gadm is not None and not gadm.empty:
        gadm.boundary.plot(ax=ax, color="k", linewidth=0.7, zorder=3)
    ax.set_xlim(LON.min() - dx, LON.max() + dx)
    ax.set_ylim(LAT.min() - dy, LAT.max() + dy)
    ax.set_aspect("equal", adjustable="box")
    ax.xaxis.set_major_locator(MultipleLocator(1))
    ax.yaxis.set_major_locator(MultipleLocator(1))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x:g}°E"))
    ax.yaxis.set_major_formatter(FuncFormatter(lambda y, _: f"{y:g}°N"))
    ax.grid(color="white", lw=0.5, alpha=0.6)
    ax.set_title(f"({tag})  {pc}", loc="left", fontweight="bold")
for ax in axes[1]:
    ax.set_xlabel("Longitude")
for ax in axes[:, 0]:
    ax.set_ylabel("Latitude")
fig.subplots_adjust(right=0.86, hspace=0.18, wspace=0.08)
cax = fig.add_axes([0.89, 0.18, 0.025, 0.64])
cb = fig.colorbar(im, cax=cax)
cb.set_label("Promax pattern loading")
for ext in ("png", "pdf"):
    out = f"{OUT_PREFIX}.{ext}"
    fig.savefig(out, dpi=300, bbox_inches="tight", facecolor="white")
    print("Tersimpan:", os.path.abspath(out))
