import xarray as xr
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import pearsonr

# =========================================================
# 1. PEMROSESAN DATA REANALISIS (ERA5)
# =========================================================
print("Memproses data ERA5...")
ds_era5 = xr.open_dataset('avgad.nc')

# Menghitung rata-rata spasial (area-averaged) untuk wilayah Kaltara
ts_era5 = ds_era5['tp'].mean(dim=['latitude', 'longitude'])

# Konversi satuan: ERA5 (meter/hari) diubah ke estimasi (mm/bulan)
# Dikalikan 1000 (ke mm) dan dikalikan 30 (rata-rata hari dalam sebulan)
ts_era5 = ts_era5 * 1000 * 30

# Memotong waktu dari 1955 hingga 2020 (Menyesuaikan irisan data GPCC)
ts_era5 = ts_era5.sel(valid_time=slice('1955-01-01', '2020-12-31'))

# Mengekstrak musim DJF
ts_era5_djf = ts_era5.where(ts_era5['valid_time'].dt.season == 'DJF', drop=True)

# Agregasi ke rata-rata musiman (Tiap tahun)
ts_era5_musiman = ts_era5_djf.resample(valid_time='QS-DEC').mean()

# Konversi ERA5 ke Pandas DataFrame dan bersihkan data
df_era5 = ts_era5_musiman.to_dataframe()
df_era5 = df_era5.dropna() # Membuang baris kuartal yang kosong
df_era5.index = df_era5.index.strftime('%Y-%m') # Format waktu YYYY-MM
df_era5.rename(columns={'tp': 'Curah_Hujan_ERA5'}, inplace=True)

# =========================================================
# 2. PEMROSESAN DATA OBSERVASI (GPCC)
# =========================================================
print("Memproses data GPCC dari Excel...")
# Membaca file Excel yang belum dibersihkan
file_gpcc = 'Validasi_GPCC_Kaltara_1955_2020.xlsx'
df_gpcc = pd.read_excel(file_gpcc, index_col='time')

# Otomatis membuang baris kosong (NaN) bawaan dari proses sebelumnya
df_gpcc = df_gpcc.dropna()

# Pastikan indeks bertipe string agar bisa digabungkan dengan ERA5
df_gpcc.index = df_gpcc.index.astype(str)

# =========================================================
# 3. PENGGABUNGAN DATA (MERGE)
# =========================================================
print("Menggabungkan deret waktu...")
# Menggabungkan ERA5 dan GPCC berdasarkan indeks waktu yang sama
df_merge = pd.merge(df_gpcc, df_era5, left_index=True, right_index=True, how='inner')

# Mengambil array nilainya saja untuk perhitungan statistik
gpcc_vals = df_merge['Curah_Hujan_GPCC_DJF_mm_month'].values
era5_vals = df_merge['Curah_Hujan_ERA5'].values

# =========================================================
# 4. PERHITUNGAN STATISTIK (KORELASI PEARSON & RMSE)
# =========================================================
# Menghitung Pearson r dan p-value (tingkat signifikansi)
r_val, p_val = pearsonr(gpcc_vals, era5_vals)

# Menghitung Root Mean Square Error (RMSE)
rmse = np.sqrt(np.mean((gpcc_vals - era5_vals)**2))

print("-" * 30)
print("HASIL VALIDASI STATISTIK")
print("-" * 30)
print(f"Korelasi Pearson (r) : {r_val:.3f}")
print(f"P-value              : {p_val:.3e}")
print(f"RMSE                 : {rmse:.2f} mm/bulan")
print("-" * 30)

# =========================================================
# 5. VISUALISASI SCATTER PLOT (Kualitas Jurnal Q1)
# =========================================================
print("Membuat Scatter Plot...")
fig, ax = plt.subplots(figsize=(7, 6))

# Membuat diagram pencar (Scatter plot)
ax.scatter(gpcc_vals, era5_vals, color='#1f77b4', alpha=0.8, edgecolor='k', s=60, label='Data Musiman (DJF)')

# Membuat Garis Regresi (Trendline)
m, b = np.polyfit(gpcc_vals, era5_vals, 1)
ax.plot(gpcc_vals, m * gpcc_vals + b, color='red', linestyle='--', linewidth=2, label='Linear Fit')

# Menambahkan kotak teks berisi nilai statistik di dalam grafik
teks_statistik = f"Pearson $r$ = {r_val:.2f}\n$p$-value < 0.001\nRMSE = {rmse:.1f} mm"
ax.text(0.05, 0.95, teks_statistik, transform=ax.transAxes, fontsize=12,
        verticalalignment='top', bbox=dict(boxstyle='round,pad=0.5', facecolor='white', edgecolor='gray', alpha=0.9))

# Merapikan label dan judul
ax.set_title('Evaluasi Presipitasi DJF ERA5 vs GPCC\nKalimantan Utara (1955–2020)', fontsize=13, fontweight='bold', pad=15)
ax.set_xlabel('Observasi GPCC (mm/bulan)', fontsize=11)
ax.set_ylabel('Reanalisis ERA5 (mm/bulan)', fontsize=11)

# Menambahkan grid dan legenda
ax.grid(True, linestyle='--', alpha=0.5, color='gray')
ax.legend(loc='lower right', fontsize=10)

plt.tight_layout()

# Menyimpan gambar dengan standar publikasi jurnal (300 DPI)
output_gambar = "Fig2_ScatterPlot_Validasi_ERA5_GPCC.png"
plt.savefig(output_gambar, dpi=300, bbox_inches='tight', format='png')
print(f"Selesai! Gambar berhasil disimpan sebagai: {output_gambar}")

# plt.show() # Hapus tanda pagar jika ingin melihat gambar pop-up