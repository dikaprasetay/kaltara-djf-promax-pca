# ============================================================
# FIGURE 2 - POLA VARIABILITAS CURAH HUJAN (PCA ROTASI PROMAX)
# Wilayah: Kalimantan Utara | Musim: DJF
# Windows CMD | Tanpa Cartopy | Menggunakan shapefile GADM lokal
# ============================================================

from pathlib import Path
import sys
import warnings

import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import geopandas as gpd
from shapely.geometry import box
from sklearn.decomposition import PCA
from factor_analyzer import Rotator


# ------------------------------------------------------------
# 1. PENGATURAN
# ------------------------------------------------------------

FOLDER = Path(r"C:\Users\user\Documents\data_jurnal\newdata")
FILE_NC = FOLDER / "avgad.nc"
SHP_FOLDER = FOLDER / "gadm41_IDN_shp"
OUTPUT_PNG = FOLDER / "Figure2_loading_patterns.png"

LAT_MIN, LAT_MAX = 1.0, 4.5
LON_MIN, LON_MAX = 114.5, 118.0

N_PC = 4
MAX_PCA_COMPONENTS = 10

# GADM tingkat provinsi. Jika nama file berbeda, ubah sesuai
# hasil perintah CMD: dir "...\\gadm41_IDN_shp\\*.shp"
SHP_FILE = SHP_FOLDER / "gadm41_IDN_1.shp"


def find_coordinate(ds, possible_names):
    """Cari nama koordinat yang tersedia pada dataset."""
    for name in possible_names:
        if name in ds.coords:
            return name
    return None


def main():
    # --------------------------------------------------------
    # 2. PERIKSA FILE INPUT
    # --------------------------------------------------------
    if not FILE_NC.is_file():
        raise FileNotFoundError(
            f"File NetCDF tidak ditemukan:\n{FILE_NC}"
        )

    if not SHP_FOLDER.is_dir():
        raise FileNotFoundError(
            f"Folder shapefile tidak ditemukan:\n{SHP_FOLDER}"
        )

    print("=" * 65)
    print("PCA ROTASI PROMAX - POLA VARIABILITAS CURAH HUJAN DJF")
    print("=" * 65)
    print("File data :", FILE_NC)
    print("Folder peta:", SHP_FOLDER)

    # --------------------------------------------------------
    # 3. BACA DATA NETCDF
    # --------------------------------------------------------
    with xr.open_dataset(FILE_NC) as source:
        ds = source.load()

    print("\nKoordinat:", list(ds.coords))
    print("Variabel:", list(ds.data_vars))

    if "tp" not in ds.data_vars:
        raise ValueError(
            "Variabel 'tp' tidak ditemukan. "
            "Periksa nama variabel curah hujan dengan print(ds)."
        )

    time_name = find_coordinate(ds, ("valid_time", "time"))
    lat_name = find_coordinate(ds, ("latitude", "lat"))
    lon_name = find_coordinate(ds, ("longitude", "lon"))

    if time_name is None:
        raise ValueError("Koordinat waktu valid_time/time tidak ditemukan.")
    if lat_name is None or lon_name is None:
        raise ValueError("Koordinat latitude/longitude tidak ditemukan.")

    tp = ds["tp"]

    for dim_name in (time_name, lat_name, lon_name):
        if dim_name not in tp.dims:
            raise ValueError(
                f"Dimensi {dim_name!r} tidak ditemukan dalam variabel tp."
            )

    # --------------------------------------------------------
    # 4. SUBSET WILAYAH KALIMANTAN UTARA
    # --------------------------------------------------------
    lat_values = ds[lat_name].values

    if lat_values.size < 1:
        raise ValueError("Koordinat latitude kosong.")

    # xarray slice harus mengikuti arah koordinat latitude.
    if lat_values[0] > lat_values[-1]:
        lat_slice = slice(LAT_MAX, LAT_MIN)
    else:
        lat_slice = slice(LAT_MIN, LAT_MAX)

    ds_region = ds.sel({
        lat_name: lat_slice,
        lon_name: slice(LON_MIN, LON_MAX),
    })

    if (
        ds_region.sizes.get(lat_name, 0) == 0
        or ds_region.sizes.get(lon_name, 0) == 0
    ):
        raise ValueError(
            "Subset wilayah kosong. Periksa batas koordinat "
            "dan rentang koordinat pada avgad.nc."
        )

    print("\nJumlah grid latitude:", ds_region.sizes[lat_name])
    print("Jumlah grid longitude:", ds_region.sizes[lon_name])

    # --------------------------------------------------------
    # 5. PILIH DATA DJF DAN KELOMPOKKAN MENURUT MUSIM
    # --------------------------------------------------------
    time = ds_region[time_name]
    month = time.dt.month

    mask_djf = (month == 12) | (month == 1) | (month == 2)
    ds_djf = ds_region.isel({
        time_name: np.asarray(mask_djf.values, dtype=bool)
    })

    if ds_djf.sizes.get(time_name, 0) == 0:
        raise ValueError("Tidak ditemukan data Desember, Januari, atau Februari.")

    selected_time = ds_djf[time_name]
    selected_year = selected_time.dt.year
    selected_month = selected_time.dt.month

    # Musim diberi label tahun akhirnya:
    # Desember 2000 + Januari/Februari 2001 -> DJF 2001.
    season_year = selected_year + (selected_month == 12).astype(int)
    ds_djf = ds_djf.assign_coords(
        season_year=(time_name, season_year.values)
    )

    print("Jumlah waktu DJF:", ds_djf.sizes[time_name])

    # --------------------------------------------------------
    # 6. KONVERSI SATUAN tp - PERIKSA SEBELUM ANALISIS
    # --------------------------------------------------------
    tp_djf = ds_djf["tp"]
    units = str(tp_djf.attrs.get("units", "tidak dicantumkan"))
    long_name = str(tp_djf.attrs.get("long_name", "tidak dicantumkan"))

    print("\nInformasi variabel tp:")
    print("  units    :", units)
    print("  long_name:", long_name)

    # PENTING:
    # Rumus ini mengikuti asumsi script awal pengguna: tp adalah
    # laju harian dalam m/hari, sehingga dikali 1000 mm/m dan
    # 30 hari. Jangan gunakan asumsi ini sebelum memverifikasi
    # metadata dan frekuensi data.
    #
    # Jika tp merupakan total akumulasi per hari dalam meter,
    # gunakan: tp_mm = tp_djf * 1000
    #
    # Jika tp merupakan akumulasi bulanan dalam meter, gunakan:
    # tp_mm = tp_djf * 1000
    #
    # Jika tp merupakan akumulasi ERA5 per jam/forecast step,
    # cara pengagregasian harus disesuaikan dengan struktur data.
    tp_mm = tp_djf * 1000 * 30

    # Rata-rata nilai pada bulan DJF per musim. Ini bukan total
    # curah hujan musim; untuk total musim, gunakan sum setelah
    # memastikan interval dan satuan data sudah benar.
    tp_season = tp_mm.groupby("season_year").mean(
        dim=time_name,
        skipna=True
    )

    tp_season = tp_season.transpose(
        "season_year", lat_name, lon_name
    )

    years = tp_season["season_year"].values
    data_mat = np.asarray(tp_season.values, dtype=float)

    n_years, n_lat, n_lon = data_mat.shape

    print("\nRentang musim DJF:", int(years.min()), "-", int(years.max()))
    print("Jumlah musim:", n_years)
    print("Dimensi data musim:", data_mat.shape)

    if n_years < 2:
        raise ValueError("PCA memerlukan setidaknya dua musim.")
    if n_years <= N_PC:
        raise ValueError(
            f"Hanya ada {n_years} musim. Untuk analisis {N_PC} PC, "
            "tambahkan data tahun atau kurangi N_PC."
        )

    # --------------------------------------------------------
    # 7. MATRIKS DATA DAN STANDARDISASI Z-SCORE
    # --------------------------------------------------------
    # Baris = musim, kolom = titik grid.
    X = data_mat.reshape(n_years, n_lat * n_lon)

    # Grid hanya digunakan jika semua musim bernilai finite
    # dan standar deviasinya tidak nol.
    finite_grid = np.isfinite(X).all(axis=0)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        std_all = np.nanstd(X, axis=0)

    valid_grid = finite_grid & np.isfinite(std_all) & (std_all > 0)

    if not np.any(valid_grid):
        raise ValueError(
            "Tidak ada grid valid. Periksa missing value dan data tp."
        )

    X_valid = X[:, valid_grid]
    mean_valid = X_valid.mean(axis=0)
    std_valid = X_valid.std(axis=0, ddof=0)
    X_std = (X_valid - mean_valid) / std_valid

    print("\nGrid valid:", int(valid_grid.sum()))
    print("Grid diabaikan:", int((~valid_grid).sum()))

    # --------------------------------------------------------
    # 8. PCA TANPA ROTASI
    # --------------------------------------------------------
    n_components = min(
        MAX_PCA_COMPONENTS,
        X_std.shape[0] - 1,
        X_std.shape[1],
    )

    if n_components < N_PC:
        raise ValueError(
            f"Komponen PCA maksimum yang tersedia hanya {n_components}, "
            f"sedangkan N_PC={N_PC}. Tambah jumlah musim atau kurangi N_PC."
        )

    pca = PCA(n_components=n_components)
    pca.fit(X_std)

    explained_var = pca.explained_variance_ratio_

    print("\nExplained variance PCA awal:")
    for i, value in enumerate(explained_var, start=1):
        print(f"  PC{i}: {value * 100:.2f}%")

    print(
        f"Kumulatif {N_PC} PC awal: "
        f"{explained_var[:N_PC].sum() * 100:.2f}%"
    )

    loadings_unrot = pca.components_[:N_PC].T

    # --------------------------------------------------------
    # 9. ROTASI PROMAX
    # --------------------------------------------------------
    rotator = Rotator(
        method="promax",
        power=2,
        normalize=True,
    )
    loadings_rot = rotator.fit_transform(loadings_unrot)

    # Kembalikan loading ke grid geografis.
    # Grid invalid tetap NaN, bukan nol.
    load_grid_flat = np.full(
        (n_lat * n_lon, N_PC),
        np.nan,
        dtype=float,
    )
    load_grid_flat[valid_grid, :] = loadings_rot
    load_grid = load_grid_flat.reshape(n_lat, n_lon, N_PC)

    # --------------------------------------------------------
    # 10. BACA SHAPEFILE GADM DAN POTONG KE WILAYAH KAJIAN
    # --------------------------------------------------------
    shp_file = SHP_FILE

    if not shp_file.is_file():
        candidates = sorted(SHP_FOLDER.glob("*.shp"))
        available = "\n".join(f"  - {f.name}" for f in candidates)
        raise FileNotFoundError(
            f"Shapefile yang diharapkan tidak ditemukan:\n{shp_file}\n\n"
            f"Shapefile .shp yang tersedia:\n{available or 'Tidak ada file .shp'}\n\n"
            "Ubah nilai SHP_FILE di awal script sesuai nama file yang tersedia."
        )

    gadm = gpd.read_file(shp_file)
    print("\nShapefile:", shp_file.name)
    print("Kolom GADM:", list(gadm.columns))
    print("CRS GADM:", gadm.crs)

    if gadm.crs is None:
        raise ValueError(
            "CRS shapefile tidak diketahui. Periksa file .prj sebelum "
            "menentukan CRS secara manual."
        )

    gadm = gadm.to_crs("EPSG:4326")
    bbox = box(LON_MIN, LAT_MIN, LON_MAX, LAT_MAX)

    # Potong geometri batas administrasi pada bounding box penelitian.
    gadm_clip = gpd.clip(gadm, bbox)

    if gadm_clip.empty:
        warnings.warn(
            "Shapefile tidak beririsan dengan bounding box. "
            "Periksa CRS dan lokasi data."
        )

    # --------------------------------------------------------
    # 11. PLOT EMPAT PETA LOADING PCA
    # --------------------------------------------------------
    lon = ds_region[lon_name].values
    lat = ds_region[lat_name].values

    fig, axes = plt.subplots(
        1,
        N_PC,
        figsize=(18, 5.5),
        sharex=True,
        sharey=True,
    )
    axes = np.atleast_1d(axes)

    # Rentang warna konsisten antar-panel agar mudah dibandingkan.
    vmin, vmax = -0.8, 0.8

    for i, ax in enumerate(axes):
        cf = ax.pcolormesh(
            lon,
            lat,
            load_grid[:, :, i],
            cmap="RdBu_r",
            shading="auto",
            vmin=vmin,
            vmax=vmax,
            zorder=1,
        )

        if not gadm_clip.empty:
            gadm_clip.boundary.plot(
                ax=ax,
                color="black",
                linewidth=0.65,
                zorder=3,
            )

        ax.set_xlim(LON_MIN, LON_MAX)
        ax.set_ylim(LAT_MIN, LAT_MAX)
        ax.set_title(f"PC{i + 1}", fontsize=12)
        ax.set_xlabel("Longitude (°E)")
        ax.set_ylabel("Latitude (°N)")
        ax.grid(
            True,
            linestyle=":",
            linewidth=0.4,
            alpha=0.5,
        )

        fig.colorbar(
            cf,
            ax=ax,
            fraction=0.046,
            pad=0.04,
            label="Loading",
        )

    fig.suptitle(
        "Figure 2. Rainfall Variability Patterns over "
        f"North Kalimantan (DJF {int(years.min())}–{int(years.max())})",
        fontsize=13,
    )

    plt.tight_layout(rect=[0, 0, 1, 0.91])
    plt.savefig(
        OUTPUT_PNG,
        dpi=300,
        bbox_inches="tight",
    )
    plt.show()

    print("\n" + "=" * 65)
    print("ANALISIS SELESAI")
    print("Gambar tersimpan di:")
    print(OUTPUT_PNG)
    print("=" * 65)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"\nERROR: {exc}", file=sys.stderr)
        sys.exit(1)
