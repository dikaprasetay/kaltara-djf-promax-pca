"""
Komposit sirkulasi atmosfer DJF untuk fase positif/negatif PC1-PC4 -- pengganti aji_fig7.py dan aji_fig6v2.py.

Jalankan (folder newdata, setelah analisis_pca_promax_70musim.py):
  py fig_sirkulasi_v2.py --msl mslworld.nc --pres 3gb.nc --scores hasil_pca\\pc_scores_promax_v2.csv --shp gadm41_IDN_shp\\gadm41_IDN_1.shp --out Fig_sirkulasi_v2

Isi gambar: warna = anomali SLP (hPa), kontur = anomali tinggi geopotensial 700 hPa (m),
vektor = anomali fluks uap 850 hPa q*V (g/kg * m/s). Kotak merah putus-putus = domain kajian.

Perbaikan dibanding skrip lama:
  1. Musim DJF benar (Des tahun sebelumnya + Jan + Feb), 70 musim. Skrip lama menggabungkan Des, Jan, Feb dari
     TAHUN KALENDER YANG SAMA (Des y dengan Jan-Feb y), sehingga bukan satu musim yang menyambung.
  2. Skor PC dari pc_scores_promax_v2.csv (tidak menghitung PCA lagi); ambang yang sama dengan Figure 3 (0.5).
  3. Kontur memakai tinggi geopotensial (m) = z/g, interval 2 m. Skrip lama memakai z (m2/s2) dengan interval 1,
     sehingga muncul ratusan kontur rapat.
  4. Fluks uap q*V dihitung per bulan lalu dirata-ratakan per musim; satuan jelas dan ada vektor acuan.
  5. Anomali terhadap baseline DJF 1981/82-2009/10, n tiap panel tertera, SLP diberi titik bila signifikan (FDR 5%).
"""
import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from scipy import stats
from gaya_gambar import terapkan_gaya, CMAP, simpan
import analisis_pca_promax_70musim as A
from fig_komposit_v2 import bh_mask

G = 9.80665


def load_field(path, var, lat_rng, lon_rng, level=None, t0='1955-01-01', t1='2025-12-31'):
    import xarray as xr
    ds = xr.open_dataset(path)
    da = ds[var]
    if level is not None:
        levels = list(map(float, ds['pressure_level'].values))
        if float(level) not in levels:
            raise ValueError('Level %s hPa tidak ada di %s. Level tersedia: %s' % (level, path, levels))
        da = da.sel(pressure_level=level)
    lat = ds['latitude'].values
    lat_slice = slice(lat_rng[1], lat_rng[0]) if lat[0] > lat[-1] else slice(lat_rng[0], lat_rng[1])
    da = da.sel(latitude=lat_slice, longitude=slice(lon_rng[0], lon_rng[1]), valid_time=slice(t0, t1)).load()
    return (pd.DatetimeIndex(da['valid_time'].values), da['latitude'].values,
            da['longitude'].values, da.values.astype('float32'))


def composite_set(anom, scores_j, thr):
    out = {}
    for phase, sel in (('pos', scores_j >= thr), ('neg', scores_j <= -thr)):
        out[phase] = (np.where(sel)[0], sel)
    return out


def make_figure(scores_df, years, lat, lon, fields, bnd, out, thr=0.5, base=(1982, 2010),
                domain=(114.5, 118.0, 1.0, 4.5)):
    """fields: dict dengan 'msl' (hPa), 'z700' (m), 'qu', 'qv' (g/kg*m/s), semuanya (musim, lat, lon)."""
    pcs = [c for c in scores_df.columns if c.upper().startswith('PC')]
    sc = scores_df.set_index('Year').loc[years, pcs].values
    b = (years >= base[0]) & (years <= base[1])
    anom = {k: v - v[b].mean(0) for k, v in fields.items()}
    terapkan_gaya()
    fig, axes = plt.subplots(len(pcs), 2, figsize=(14, 4.3 * len(pcs)), constrained_layout=True,
                             sharex=True, sharey=True)
    # skala bersama
    allmsl = []
    for j in range(len(pcs)):
        for sel in (sc[:, j] >= thr, sc[:, j] <= -thr):
            allmsl.append(np.nanmax(np.abs(anom['msl'][sel].mean(0))))
    lim = max(1.0, float(np.ceil(max(allmsl) * 2) / 2))
    mag = [np.nanmax(np.hypot(anom['qu'][s].mean(0), anom['qv'][s].mean(0)))
           for j in range(len(pcs)) for s in (sc[:, j] >= thr, sc[:, j] <= -thr)]
    ref = float(max(1, np.round(max(mag) / 2)))         # panjang vektor acuan
    LON, LAT = np.meshgrid(lon, lat)
    step = max(1, int(round(1.5 / abs(lon[1] - lon[0]))))
    rows = []
    for j, pc in enumerate(pcs):
        for c, phase in enumerate(('pos', 'neg')):
            ax = axes[j, c]
            sel = sc[:, j] >= thr if phase == 'pos' else sc[:, j] <= -thr
            m_msl = anom['msl'][sel].mean(0)
            _, p = stats.ttest_ind(anom['msl'][sel], anom['msl'][~sel], axis=0, equal_var=False)
            sig = bh_mask(np.nan_to_num(p, nan=1.0)).reshape(m_msl.shape)
            im = ax.pcolormesh(lon, lat, m_msl, cmap=CMAP, vmin=-lim, vmax=lim, shading='nearest')
            ax.scatter(LON[sig][::3], LAT[sig][::3], s=2, c='k', marker='.', linewidths=0, alpha=0.5)
            zz = anom['z700'][sel].mean(0)
            zmax = np.ceil(np.nanmax(np.abs(zz)) / 2) * 2
            if zmax >= 2:
                lv = np.arange(-zmax, zmax + 0.1, 2)
                ax.contour(lon, lat, zz, levels=lv[lv > 0], colors='k', linewidths=0.8)
                ax.contour(lon, lat, zz, levels=lv[lv < 0], colors='k', linewidths=0.8, linestyles='dashed')
            qu, qv = anom['qu'][sel].mean(0), anom['qv'][sel].mean(0)
            Q = ax.quiver(lon[::step], lat[::step], qu[::step, ::step], qv[::step, ::step],
                          angles='xy', scale_units='xy', scale=ref / 3.0, width=0.0028, color='#222222')
            if j == 0 and c == 1:
                ax.quiverkey(Q, 0.86, 0.07, ref, f'{ref:g} g/kg·m/s', labelpos='N', fontproperties={'size': 12})
            if bnd is not None:
                bnd.boundary.plot(ax=ax, color='black', linewidth=0.6)
            x0, x1, y0, y1 = domain
            ax.add_patch(Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, ec='crimson', lw=1.6, ls='--'))
            ax.set_xlim(lon.min(), lon.max()); ax.set_ylim(lat.min(), lat.max())
            sign = '≥ +%.1f' % thr if phase == 'pos' else '≤ −%.1f' % thr
            ax.set_title(f'({"abcdefgh"[2 * j + c]}) {pc} {sign} (n = {int(sel.sum())})', loc='left', fontsize=13)
            ax.grid(True, ls=':', lw=0.5, alpha=0.6); ax.set_aspect('equal', adjustable='box')
            if c == 0: ax.set_ylabel('Latitude (°N)')
            if j == len(pcs) - 1: ax.set_xlabel('Longitude (°E)')
    cb = fig.colorbar(im, ax=axes, orientation='horizontal', fraction=0.025, pad=0.02, aspect=45)
    cb.set_label('SLP anomaly (hPa; colour), Z700 anomaly (m; contours, interval 2 m), '
                 '850 hPa moisture flux anomaly q·V (vectors)')
    simpan(fig, out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--msl', default='mslworld.nc'); ap.add_argument('--pres', default='3gb.nc')
    ap.add_argument('--scores', required=True); ap.add_argument('--shp', default=None)
    ap.add_argument('--out', default='Fig_sirkulasi_v2'); ap.add_argument('--thr', type=float, default=0.5)
    ap.add_argument('--lat', type=float, nargs=2, default=[-10, 25])
    ap.add_argument('--lon', type=float, nargs=2, default=[95, 135])
    a = ap.parse_args()
    print('Membaca SLP ...')
    t, lat, lon, msl = load_field(a.msl, 'msl', a.lat, a.lon)
    print('Membaca z700, q850, u850, v850 (3gb.nc besar, mohon tunggu) ...')
    _, _, _, z = load_field(a.pres, 'z', a.lat, a.lon, level=700)
    _, _, _, q = load_field(a.pres, 'q', a.lat, a.lon, level=850)
    _, _, _, u = load_field(a.pres, 'u', a.lat, a.lon, level=850)
    _, _, _, v = load_field(a.pres, 'v', a.lat, a.lon, level=850)
    fields_monthly = {'msl': msl / 100.0, 'z700': z / G, 'qu': q * u * 1000.0, 'qv': q * v * 1000.0}
    fields, years = {}, None
    for k, arr in fields_monthly.items():
        fields[k], years = A.djf_array(t, arr)
    sc = pd.read_csv(a.scores); sc['Year'] = sc['Year'].astype(int)
    keep = np.isin(years, sc['Year'].values)
    years = years[keep]; fields = {k: v[keep] for k, v in fields.items()}
    print('Musim DJF dipakai:', len(years), '(%d-%d)' % (years.min(), years.max()))
    bnd = None
    if a.shp:
        try:
            import geopandas as gpd
            from shapely.geometry import box
            g = gpd.read_file(a.shp).to_crs('EPSG:4326')
            bnd = gpd.clip(g, box(a.lon[0], a.lat[0], a.lon[1], a.lat[1]))
        except Exception as e:
            print('Peringatan: batas wilayah dilewati (%s)' % e)
    make_figure(sc, years, lat, lon, fields, bnd, a.out, a.thr)


if __name__ == '__main__':
    main()
