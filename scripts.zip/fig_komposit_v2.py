"""
Komposit anomali hujan DJF untuk fase positif/negatif PC1-PC4 -- pengganti aji_fig4.py.

Jalankan (folder newdata, setelah analisis_pca_promax_70musim.py):
  py fig_komposit_v2.py --nc avgad.nc --scores hasil_pca\\pc_scores_promax_v2.csv --shp gadm41_IDN_shp\\gadm41_IDN_2.shp --out Fig_komposit_v2

Perbaikan dibanding aji_fig4.py:
  1. Skor dari pc_scores_promax_v2.csv (Promax, 70 musim, positif = lebih basah), bukan skor Varimax lama.
  2. Satuan mm/BULAN (aji_fig4 memakai mm/hari tetapi skala warna +-40 "mm" -> peta tampak putih/monokrom).
  3. Grid asli 0.25 derajat (tanpa interpolasi 500x500 dan tanpa pengisian nol di tepi).
  4. Jumlah tahun (n) dan daftar tahun tiap fase disimpan ke CSV; uji signifikansi (Welch t-test dengan
     kontrol FDR Benjamini-Hochberg 5%); titik = signifikan.
  5. Anomali terhadap baseline yang sama dengan analisis PCA (DJF 1981/82-2009/10).
"""
import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from gaya_gambar import terapkan_gaya, CMAP, simpan
import analisis_pca_promax_70musim as A


def bh_mask(p, q=0.05):
    p = np.asarray(p, float).ravel(); m = len(p)
    o = np.argsort(p); ok = p[o] <= (np.arange(1, m + 1) / m) * q
    k = np.where(ok)[0].max() + 1 if ok.any() else 0
    sig = np.zeros(m, bool); sig[o[:k]] = True
    return sig


def composites(anom, scores, thr=0.5):
    """anom (musim, lat, lon); scores (musim, k). Kembalikan dict[(j, 'pos'/'neg')] -> (komposit, sig, idx)."""
    out = {}
    for j in range(scores.shape[1]):
        s = scores[:, j]
        for phase, sel in (('pos', s >= thr), ('neg', s <= -thr)):
            rest = ~sel
            comp = anom[sel].mean(0)
            _, p = stats.ttest_ind(anom[sel], anom[rest], axis=0, equal_var=False)
            sig = bh_mask(np.nan_to_num(p, nan=1.0)).reshape(comp.shape)
            out[(j, phase)] = (comp, sig, np.where(sel)[0])
    return out


def read_boundary(shp_path):
    if not shp_path:
        return None
    try:
        import geopandas as gpd
        g = gpd.read_file(shp_path).to_crs('EPSG:4326')
        if 'NAME_1' in g.columns:
            sub = g[g['NAME_1'].astype(str).str.upper() == 'KALIMANTAN UTARA']
            if len(sub):
                return sub
        return g
    except Exception as e:
        print('Peringatan: batas administrasi dilewati (%s)' % e)
        return None


def make_figure(rain, lat, lon, years, scores_df, bnd, out, thr=0.5, base=(1982, 2010)):
    pcs = [c for c in scores_df.columns if c.upper().startswith('PC')]
    sc = scores_df.set_index('Year').loc[years, pcs].values            # sejajarkan tahun (label = tahun Januari)
    b = (years >= base[0]) & (years <= base[1])
    anom = rain - rain[b].mean(0)
    print('Rata-rata |anomali| = %.1f mm/bulan (harus puluhan mm/bulan, bukan sekitar 1)' % np.nanmean(np.abs(anom)))
    res = composites(anom, sc, thr)
    lim = float(np.ceil(max(np.nanmax(np.abs(v[0])) for v in res.values()) / 10) * 10)
    terapkan_gaya()
    fig, axes = plt.subplots(len(pcs), 2, figsize=(11, 4.4 * len(pcs)), constrained_layout=True,
                             sharex=True, sharey=True)
    LON, LAT = np.meshgrid(lon, lat)
    rows = []
    letters = 'abcdefgh'
    for j, pc in enumerate(pcs):
        for c, phase in enumerate(('pos', 'neg')):
            ax = axes[j, c]
            comp, sig, idx = res[(j, phase)]
            im = ax.pcolormesh(lon, lat, comp, cmap=CMAP, vmin=-lim, vmax=lim, shading='nearest')
            ax.scatter(LON[sig], LAT[sig], s=7, c='k', marker='.', linewidths=0)
            if bnd is not None:
                bnd.boundary.plot(ax=ax, color='black', linewidth=0.9)
            ax.set_xlim(lon.min() - 0.125, lon.max() + 0.125)
            ax.set_ylim(min(lat) - 0.125, max(lat) + 0.125)
            sign = '≥ +%.1f' % thr if phase == 'pos' else '≤ −%.1f' % thr
            ax.set_title(f'({letters[2 * j + c]}) {pc} {sign} (n = {len(idx)})', loc='left', fontsize=13)
            ax.grid(True, ls=':', lw=0.5, alpha=0.6); ax.set_aspect('equal', adjustable='box')
            if c == 0: ax.set_ylabel('Latitude (°N)')
            if j == len(pcs) - 1: ax.set_xlabel('Longitude (°E)')
            for i in idx:
                rows.append(dict(PC=pc, phase=phase, season='DJF %d/%02d' % (years[i] - 1, years[i] % 100)))
    cb = fig.colorbar(im, ax=axes, orientation='horizontal', fraction=0.025, pad=0.03, aspect=40)
    cb.set_label('Composite DJF rainfall anomaly (mm/month); dots: significant (FDR 5%)')
    simpan(fig, out)
    pd.DataFrame(rows).to_csv(out + '_tahun_komposit.csv', index=False)
    print('Daftar tahun komposit:', out + '_tahun_komposit.csv')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--nc', default='avgad.nc')
    ap.add_argument('--scores', required=True)
    ap.add_argument('--shp', default=None)
    ap.add_argument('--out', default='Fig_komposit_v2')
    ap.add_argument('--thr', type=float, default=0.5)
    a = ap.parse_args()
    import xarray as xr
    ds = xr.open_dataset(a.nc)
    t = pd.DatetimeIndex(pd.to_datetime(ds['valid_time'].values))
    lat, lon = ds['latitude'].values, ds['longitude'].values
    mm = A.to_mm_month(t, ds['tp'].values.astype('float64'))
    rain, years = A.djf_array(t, mm)
    sc = pd.read_csv(a.scores); sc['Year'] = sc['Year'].astype(int)
    print('Musim:', len(years), '| skor:', len(sc))
    make_figure(rain, lat, lon, years, sc, read_boundary(a.shp), a.out, a.thr)


if __name__ == '__main__':
    main()
