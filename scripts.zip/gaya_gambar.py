"""Gaya bersama untuk SEMUA gambar jurnal (jawab komentar font/warna reviewer).
Pakai di setiap skrip gambar:
    from gaya_gambar import terapkan_gaya, CMAP, simpan
    terapkan_gaya()
Aturan: font >= 12, label bahasa Inggris, merah = positif/lebih basah, biru = negatif/lebih kering,
PNG 300 dpi + PDF vektor.
"""
import matplotlib as mpl

CMAP = 'RdBu_r'          # merah = positif/tinggi, biru = negatif/rendah (konsisten di semua gambar)


def terapkan_gaya():
    mpl.rcParams.update({
        'font.family': 'DejaVu Sans', 'font.size': 13,
        'axes.titlesize': 14, 'axes.titleweight': 'bold', 'axes.labelsize': 13,
        'xtick.labelsize': 12, 'ytick.labelsize': 12, 'legend.fontsize': 12,
        'figure.titlesize': 15, 'savefig.dpi': 300, 'savefig.bbox': 'tight',
        'pdf.fonttype': 42,
    })


def simpan(fig, nama_tanpa_ekstensi):
    fig.savefig(nama_tanpa_ekstensi + '.png', dpi=300, bbox_inches='tight')
    fig.savefig(nama_tanpa_ekstensi + '.pdf', bbox_inches='tight')
    print('Tersimpan:', nama_tanpa_ekstensi + '.png / .pdf')
